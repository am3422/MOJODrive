# v0.16 equivalence proof (one-time, local)

Proves that moving the camera engine out of `LocationService.kt` (v0.15) into
`CameraEngine.kt` (v0.16) changed **no behavior**.

`build_original_harness.py` pastes the ORIGINAL v0.15 camera functions verbatim into a JVM
class (Android `Location` → AOSP Vincenty port, `SystemClock` → replay clock, logging and
sound → recorder). The harness then replays every golden trip through both the original
code and the new `CameraEngine`, with and without the 500 ms GPS-bridge ticker, and compares
every camera event.

Result at packaging time: **7,109 / 7,109 events identical**. The same run wrote
`tools/fixtures/engine_decisions_v015.tsv`, which `EngineBehaviorLockTest` now enforces in CI,
so this proof does not need to be repeated.

To reproduce (needs a JDK 17+ and a Kotlin 2.0 compiler, `kotlinc`):

```bash
git show 1c00506:app/src/main/java/com/mojotech/mojodrive/LocationService.kt > /tmp/LocationService_v015.kt
mkdir -p /tmp/eq   # the generated file must be named OriginalHarness.kt
python3 tools/v016_equivalence/build_original_harness.py . /tmp/LocationService_v015.kt /tmp/eq/OriginalHarness.kt
kotlinc /tmp/eq/OriginalHarness.kt app/src/main/java/com/mojotech/mojodrive/CameraEngine.kt \
  app/src/test/java/com/mojotech/mojodrive/AospGeodesy.kt app/src/test/java/com/mojotech/mojodrive/TripReplay.kt \
  -include-runtime -d /tmp/eq/equivalence.jar
java -cp /tmp/eq/equivalence.jar com.mojotech.mojodrive.original.OriginalHarnessKt /tmp/eq/lock.tsv
cmp /tmp/eq/lock.tsv tools/fixtures/engine_decisions_v015.tsv && echo "lock reproduced"
```
