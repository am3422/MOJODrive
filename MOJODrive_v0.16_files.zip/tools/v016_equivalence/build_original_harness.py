#!/usr/bin/env python3
"""Build a JVM harness that runs the ORIGINAL v0.15 LocationService camera code, verbatim.

Used only locally to prove the extracted CameraEngine behaves identically event-for-event.
Android pieces are replaced by tiny stubs (Location -> AOSP Vincenty port, SystemClock ->
replay clock, logging/sound -> recorder). The camera functions themselves are pasted
byte-for-byte from the original file.
"""
import re, sys
from pathlib import Path

sys.path.insert(0, sys.argv[1] + "/tools")
from baseline_guard import extract_function  # noqa

orig = Path(sys.argv[2]).read_text(encoding="utf-8")
out = Path(sys.argv[3])

FUNCS = ["buildCameraClusters", "camerasClusterCompatible", "bearingsClusterCompatible",
         "hasReliableDirectedBearing", "cameraMetadataScore", "evaluateAllCameras",
         "markCameraPassed", "buildCameraGeometry", "updateApproachState", "computeAlertRequest",
         "dispatchCameraAlerts", "alertRepeatIntervalMs", "bridgeConfirmedCameraAlerts",
         "chooseUiCamera", "clearUiCamera", "cleanupOldCameraStates",
         "computeAdaptiveWarningDistanceM", "computeCameraAlertLevel", "validDynamicLimit",
         "normalizeBearing", "angleDifference"]
funcs = "\n\n".join("    " + extract_function(orig, f) for f in FUNCS)
funcs += "\n\n    " + re.search(r"private fun normalizeRoadName\(value: String\): String =\n[^\n]+", orig).group(0)

companion = re.search(r"(?s)    companion object \{.*?\n    \}\n", orig).group(0)
types_start = orig.index("    private enum class TrackPhase {")
types_end = orig.index("    private lateinit var locationManager: LocationManager")
types = orig[types_start:types_end]

gap_loop = re.search(r"        for \(\(_, state\) in cameraStates\) \{\n.*?\n        \}\n",
                     extract_function(orig, "prepareForLocationGapRecovery"), re.S).group(0)

src = f'''package com.mojotech.mojodrive.original

import com.mojotech.mojodrive.AospGeodesy
import com.mojotech.mojodrive.CameraEngineHost
import com.mojotech.mojodrive.CameraFix
import com.mojotech.mojodrive.CameraPoint
import com.mojotech.mojodrive.TripReplay
import java.util.Locale
import kotlin.math.*

object SystemClock {{ var now = 0L; fun elapsedRealtime() = now }}

class Location(@Suppress("UNUSED_PARAMETER") provider: String) {{
    var latitude = 0.0
    var longitude = 0.0
    fun distanceTo(o: Location): Float {{ val r = FloatArray(2); distanceBetween(latitude, longitude, o.latitude, o.longitude, r); return r[0] }}
    fun bearingTo(o: Location): Float {{ val r = FloatArray(2); distanceBetween(latitude, longitude, o.latitude, o.longitude, r); return r[1] }}
    companion object {{
        fun distanceBetween(a: Double, b: Double, c: Double, d: Double, r: FloatArray) = AospGeodesy.distanceBetween(a, b, c, d, r)
    }}
}}

/** ORIGINAL v0.15 LocationService camera code, verbatim, driven by the replay. */
class OriginalCameraService(
    private val cameras: List<CameraPoint>,
    private val recorder: TripReplay.RecordingHost
) : TripReplay.ReplayEngine {{
{companion}
{types}
    private val roadGeometryShadow: Any? = null
    private fun Any?.evaluate(vararg a: Any?): Explicit? = null
    private class Explicit(val verdict: String, val evidenceKind: String, val negativeLabel: String?, val corridorDistanceM: Float, val headingDeltaDeg: Float)
    private object RoadGeometryShadow {{ const val POLICY = "replay_no_negative_routes" }}

    private val cameraClusters: List<CameraCluster> = buildCameraClusters(cameras)
    private val cameraStates = HashMap<String, CameraTrackState>()
    private var globalLastCameraPulseElapsed = 0L
    private var globalLastCameraKey = ""
    private var cameraAlertZoneActive = false
    private var latestLat = Double.NaN
    private var latestLon = Double.NaN
    private var latestBearing = -1f
    private var latestBearingValid = false
    private var latestAccuracy = -1f
    private var latestSpeedKmh = 0f
    private var recoveredLocationGapMs = 0L
    private var manualThresholdKmh = 80
    private var activeLimitKmh = 80
    private var activeCameraId = ""
    private var activeCameraType = ""
    private var activeCameraDistanceM = -1f
    private var activeCameraSpeedLimit: Int? = null
    private var activeCameraRoadName = ""
    private var activeCameraCurveCrossM = -1f
    private var activeCameraForwardDelta = -1f
    private var activeCameraAlertLevel = 0
    private var activeCameraTtcS = -1f
    private var activeCameraWarningDistanceM = -1f
    private var confirmedCameraCount = 0

    private fun pub(g: CameraGeometry) = com.mojotech.mojodrive.CameraGeometry(
        com.mojotech.mojodrive.CameraCluster(g.cluster.key, g.cluster.camera, g.cluster.memberIds),
        g.directDistanceM, g.vehicleForwardM, g.vehicleCrossM, g.bearingToCameraDeg, g.forwardDeltaDeg,
        g.roadCrossM, g.curveCrossM, g.roadAxisDeltaDeg, g.roadDirectionDeltaDeg, g.hardCrossLimitM,
        g.hardCrossOk, g.directionGateOk, g.hardGeometryOk, g.warningDistanceM, g.ttcS, g.candidateLimit,
        g.approachDeltaM, g.approachRateMps, g.matchScore, g.requiredScore, g.requiredHits, g.matchReason)

    private fun pub(s: CameraTrackState) = com.mojotech.mojodrive.CameraTrackState(
        phase = com.mojotech.mojodrive.TrackPhase.valueOf(s.phase.name), warned = s.warned)

    private fun appendCameraEvent(event: String, geometry: CameraGeometry, state: CameraTrackState, extra: String) =
        recorder.cameraEvent(event, pub(geometry), pub(state), extra)

    private fun dispatchCameraAlertOutput(request: AlertRequest, suppressedCount: Int, firstAlert: Boolean) =
        recorder.cameraAlertOutput(
            com.mojotech.mojodrive.AlertRequest(pub(request.geometry), pub(request.state), request.level, request.bridge),
            suppressedCount, firstAlert)

    override fun resetTrackingAfterLocationGap() {{
{gap_loop}    }}

    override fun evaluateAndDispatch(fix: CameraFix) {{
        SystemClock.now = fix.nowElapsedMs
        latestLat = fix.lat; latestLon = fix.lon; latestBearing = fix.bearingDeg; latestBearingValid = true
        latestAccuracy = fix.accuracyM; latestSpeedKmh = fix.speedKmh; recoveredLocationGapMs = fix.recoveredLocationGapMs
        evaluateAllCameras()
    }}

    override fun bridgeAndDispatch(locationAgeMs: Long, speedKmh: Float) {{
        latestSpeedKmh = speedKmh
        bridgeConfirmedCameraAlerts(locationAgeMs)
    }}

{funcs}
}}

val originalEngine = TripReplay.EngineFactory {{ cameras, host, clock ->
    val recorder = host as TripReplay.RecordingHost
    val svc = OriginalCameraService(cameras, recorder)
    object : TripReplay.ReplayEngine by svc {{
        override fun evaluateAndDispatch(fix: CameraFix) {{ SystemClock.now = clock(); svc.evaluateAndDispatch(fix) }}
        override fun bridgeAndDispatch(locationAgeMs: Long, speedKmh: Float) {{ SystemClock.now = clock(); svc.bridgeAndDispatch(locationAgeMs, speedKmh) }}
    }}
}}

fun main(args: Array<String>) {{
    val (_, cameras) = TripReplay.loadCameraSnapshot()
    val lock = ArrayList<String>()
    val (_, golden) = TripReplay.loadGolden()
    var mismatches = 0
    var totalEvents = 0
    for (ticker in listOf(false, true)) {{
        for (trip in golden.keys) {{
            val a = TripReplay.replay(trip, cameras, originalEngine, ticker)
            val b = TripReplay.replay(trip, cameras, TripReplay.realEngine, ticker)
            totalEvents += a.events.size
            lock += a.decisionLines(ticker)
            val same = a.events == b.events && a.outputs == b.outputs
            if (!same) {{
                mismatches++
                val i = a.events.indices.firstOrNull {{ it >= b.events.size || a.events[it] != b.events[it] }}
                println("MISMATCH $trip ticker=$ticker at event $i\\n  original=${{i?.let {{ a.events.getOrNull(it) }}}}\\n  engine  =${{i?.let {{ b.events.getOrNull(it) }}}}")
            }}
            println("  ${{if (same) "IDENTICAL" else "DIFFERENT"}} ticker=$ticker $trip events=${{a.events.size}} outputs=${{a.outputs.size}} " +
                "confirmed=${{a.count("CAMERA_MATCH_CONFIRMED")}} warnings=${{a.count("CAMERA_WARNING")}} bridge=${{a.count("CAMERA_GPS_BRIDGE_START")}}")
        }}
    }}
    if (args.isNotEmpty()) {{
        java.io.File(args[0]).writeText(
            "# MOJO Drive camera-engine behavior lock. Generated by running the ORIGINAL v0.15\\n" +
            "# LocationService camera code (commit 1c00506) over every golden trip, with and without\\n" +
            "# the 500 ms GPS-bridge ticker. Columns: trip mode time_ms event cluster phase warned extra\\n" +
            lock.joinToString("\\n") + "\\n", Charsets.UTF_8)
        println("wrote ${{lock.size}} decision rows to ${{args[0]}}")
    }}
    println(if (mismatches == 0) "DIFFERENTIAL: PASS — original v0.15 code and CameraEngine produced identical $totalEvents events" else "DIFFERENTIAL: FAIL ($mismatches)")
}}
'''
out.write_text(src, encoding="utf-8")
print("wrote", out)
