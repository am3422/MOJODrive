#!/usr/bin/env python3
"""Export the bundled camera DB as a plain-text snapshot for the Kotlin unit tests.

Why: JVM unit tests cannot use Android's SQLite. The Kotlin replay tests therefore read this
snapshot instead. The snapshot is exactly what CameraDatabase.loadAll() returns: same rows,
same order, same null handling, floats written with full round-trip precision.

    python3 tools/export_camera_snapshot.py           # (re)write the snapshot
    python3 tools/export_camera_snapshot.py --check   # CI: fail if snapshot != bundled DB
"""
from __future__ import annotations

import argparse
import hashlib
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "app/src/main/assets/shiraz_cameras.sqlite"
SNAPSHOT = ROOT / "tools/fixtures/camera_db_snapshot.tsv"

# Same query as CameraDatabase.loadAll() (no ORDER BY there either: table scan order).
QUERY = (
    "SELECT camera_id, camera_type, latitude, longitude, speed_limit, road_name, road_highway, "
    "road_distance_m, speed_source, speed_confidence, road_bearing, oneway, "
    "direction_mode, direction_confidence FROM cameras"
)
COLUMNS = ["id", "type", "latitude", "longitude", "speedLimit", "roadName", "roadHighway",
           "roadDistanceM", "speedSource", "speedConfidence", "roadBearing", "oneway",
           "directionMode", "directionConfidence"]
NULL = "\\N"


def text(v, default):
    s = default if v is None else str(v)
    if "\t" in s or "\n" in s or s == NULL:
        raise SystemExit(f"value cannot be represented in snapshot: {s!r}")
    return s


def render() -> str:
    sha = hashlib.sha256(DB.read_bytes()).hexdigest()
    con = sqlite3.connect(DB)
    try:
        rows = con.execute(QUERY).fetchall()
    finally:
        con.close()

    out = [f"# camera_db_sha256={sha}", "# " + "\t".join(COLUMNS)]
    for r in rows:
        (cid, ctype, lat, lon, limit, road, highway, road_d, src, speed_conf,
         bearing, oneway, dmode, dconf) = r
        out.append("\t".join([
            text(cid, ""),                                   # getString ?: ""
            text(ctype, "speed"),                            # getString ?: "speed"
            repr(float(lat)),
            repr(float(lon)),
            NULL if limit is None else str(int(limit)),
            text(road, ""),
            text(highway, ""),
            NULL if road_d is None else repr(float(road_d)),
            text(src, ""),
            text(speed_conf, "unknown"),
            NULL if bearing is None else repr(float(bearing)),  # Kotlin narrows to Float like getFloat
            "true" if (oneway is not None and int(oneway) == 1) else "false",
            text(dmode, "unknown"),
            text(dconf, "unknown"),
        ]))
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    expected = render()
    if args.check:
        actual = SNAPSHOT.read_text(encoding="utf-8") if SNAPSHOT.exists() else ""
        if actual != expected:
            print("CAMERA SNAPSHOT CHECK: FAIL — tools/fixtures/camera_db_snapshot.tsv does not match")
            print("the bundled shiraz_cameras.sqlite. Regenerate it with:")
            print("  python3 tools/export_camera_snapshot.py")
            return 2
        print(f"CAMERA SNAPSHOT CHECK: PASS ({expected.count(chr(10)) - 2} cameras, matches bundled DB)")
        return 0
    SNAPSHOT.write_text(expected, encoding="utf-8")
    print(f"wrote {SNAPSHOT.relative_to(ROOT)} ({expected.count(chr(10)) - 2} cameras)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
