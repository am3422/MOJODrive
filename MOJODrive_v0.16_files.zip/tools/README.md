# MOJO Drive regression tools

`baseline_guard.py` locks the field-validated v0.12 runtime engine in CI. It fails the build if a protected camera/location/speed function or critical threshold changes accidentally.

`replay_harness.py` replays the locked camera matcher against four successful field traces (three v0.12 trips plus the successful v0.13 shadow trip). `--self-test` must reproduce all **57/57** first-warning encounters in the exact recorded order.

`build_road_geometry_db.py` rebuilds the diagnostic road-geometry SQLite DB from proven near-pass field traces. It can retain multiple distinct, field-proven approaches for one camera. In v0.14 this DB remains **shadow only** and never changes alerts.

`road_geometry_shadow_test.py` validates the conservative multi-approach shadow policy against field-derived regression cases, including the v0.13 `14302` false-conflict discovery and both the abandoned and real `14427` approaches.

Useful commands:

```bash
python3 tools/baseline_guard.py
python3 tools/replay_harness.py --self-test
python3 tools/road_geometry_shadow_test.py
```

## v0.16: Kotlin tests of the real engine

The camera engine now lives in `app/src/main/java/com/mojotech/mojodrive/CameraEngine.kt`
(pure Kotlin). JVM unit tests in `app/src/test/` replay the golden trips through that exact
class — the same code the APK runs — instead of the Python copy:

- `GoldenReplayTest` — 77/77 first warnings, first-alert guarantee, silence after pass
- `EngineBehaviorLockTest` — full decision timeline must match `fixtures/engine_decisions_v015.tsv`
- `NegativeRouteVetoTest` — the v0.15 veto stays explicit-only, first-alert-only

`export_camera_snapshot.py` exports `shiraz_cameras.sqlite` to `fixtures/camera_db_snapshot.tsv`
for those tests (`--check` in CI). `v016_equivalence/` holds the one-time proof that the move
changed nothing (7,109/7,109 events identical).

```bash
python3 tools/export_camera_snapshot.py --check
gradle :app:testDebugUnitTest     # GitHub Actions runs this on every push / pull request
```
