plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mojotech.mojodrive"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mojotech.mojodrive"
        minSdk = 26
        targetSdk = 35
        versionCode = 16
        versionName = "0.16"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}


dependencies {
    implementation("com.google.android.gms:play-services-location:21.3.0")

    // v0.16: JVM unit tests replay recorded field trips through the real CameraEngine.
    testImplementation("junit:junit:4.13.2")
}

tasks.withType<Test>().configureEach {
    testLogging {
        events("passed", "failed")
        showStandardStreams = true
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
    }
}
