package com.mojotech.mojodrive

import java.util.Locale
import kotlin.math.*

/*
 * MOJO Drive camera decision engine (v0.16).
 *
 * This is the field-validated v0.12 camera matcher (+ the v0.15 guarded negative-route veto),
 * moved out of LocationService WITHOUT changing any rule, threshold, or ordering. It contains
 * no Android code, so the exact same engine runs inside the app AND inside the JVM unit tests
 * that replay recorded field trips (app/src/test).
 *
 * Android-specific work is injected:
 *   - Geodesy             distance + bearing (the app uses android.location.Location.distanceBetween)
 *   - CameraEngineHost    CSV logging, explicit negative-route lookup, tone/vibration output
 *   - clock               elapsed-time source (the app uses SystemClock.elapsedRealtime)
 */

data class CameraPoint(
    val id: String,
    val type: String,
    val latitude: Double,
    val longitude: Double,
    val speedLimit: Int?,
    val roadName: String,
    val roadHighway: String,
    val roadDistanceM: Double?,
    val speedSource: String,
    val speedConfidence: String,
    val roadBearing: Float?,
    val oneway: Boolean,
    val directionMode: String,
    val directionConfidence: String
)

/** distanceBetween contract identical to android.location.Location.distanceBetween. */
fun interface Geodesy {
    fun distanceBetween(lat1: Double, lon1: Double, lat2: Double, lon2: Double, results: FloatArray)
}

/** Pure copy of the RoadGeometryShadow.Result fields used by the guarded live veto. */
data class NegativeRouteEvidence(
    val verdict: String,
    val evidenceKind: String,
    val negativeLabel: String?,
    val corridorDistanceM: Float,
    val headingDeltaDeg: Float
)

interface CameraEngineHost {
    val negativeRoutePolicy: String
    fun cameraEvent(event: String, geometry: CameraGeometry, state: CameraTrackState, extra: String)
    fun explicitNegativeRoute(
        cameraIds: List<String>,
        cameraType: String,
        lat: Double,
        lon: Double,
        vehicleBearingDeg: Float?
    ): NegativeRouteEvidence?
    fun cameraAlertOutput(request: AlertRequest, suppressedCount: Int, firstAlert: Boolean)
}

/** One accepted location fix, exactly as LocationService sees it when it evaluates cameras. */
data class CameraFix(
    val nowElapsedMs: Long,
    val lat: Double,
    val lon: Double,
    val bearingDeg: Float,
    val accuracyM: Float,
    val speedKmh: Float,
    val recoveredLocationGapMs: Long
)

data class CameraEvaluation(
    val confirmedGeometries: List<CameraGeometry>,
    val alertRequests: List<AlertRequest>
)

enum class TrackPhase {
    TRACKING, CONFIRMED, PASSED, ABANDONED
}

data class CameraCluster(
    val key: String,
    val camera: CameraPoint,
    val memberIds: List<String>
)

data class CameraGeometry(
    val cluster: CameraCluster,
    val directDistanceM: Float,
    val vehicleForwardM: Float,
    val vehicleCrossM: Float,
    val bearingToCameraDeg: Float,
    val forwardDeltaDeg: Float,
    val roadCrossM: Float,
    val curveCrossM: Float,
    val roadAxisDeltaDeg: Float,
    val roadDirectionDeltaDeg: Float,
    val hardCrossLimitM: Float,
    val hardCrossOk: Boolean,
    val directionGateOk: Boolean,
    val hardGeometryOk: Boolean,
    val warningDistanceM: Float,
    val ttcS: Float,
    val candidateLimit: Int?,
    val approachDeltaM: Float,
    val approachRateMps: Float,
    val matchScore: Int,
    val requiredScore: Int,
    val requiredHits: Int,
    val matchReason: String
)

data class CameraTrackState(
    var phase: TrackPhase = TrackPhase.TRACKING,
    var confirmHits: Int = 0,
    var approachHits: Int = 0,
    var awayHits: Int = 0,
    var hardBadHits: Int = 0,
    var warned: Boolean = false,
    var urgentLogged: Boolean = false,
    var nearPassAudited: Boolean = false,
    var alertLevel: Int = 0,
    var lastDiagElapsed: Long = 0L,
    var lastSeenElapsed: Long = 0L,
    var transitionElapsed: Long = 0L,
    var lastDistanceM: Float = Float.MAX_VALUE,
    var minDistanceM: Float = Float.MAX_VALUE,
    var lastGeometry: CameraGeometry? = null,
    var lastGeometryElapsed: Long = 0L,
    var bridgeLogged: Boolean = false,
    var warningStartedElapsed: Long = 0L,
    var firstAlertDelivered: Boolean = false,
    var lastPulseElapsed: Long = 0L,
    var missedDuringGapLogged: Boolean = false,
    var explicitNegativeSuppressionLogged: Boolean = false
)

data class AlertRequest(
    val geometry: CameraGeometry,
    val state: CameraTrackState,
    val level: Int,
    val bridge: Boolean
)

class CameraEngine(
    cameras: List<CameraPoint>,
    private val geo: Geodesy,
    private val host: CameraEngineHost,
    private val clock: () -> Long
) {

    companion object {
        private const val LOCATION_STALE_MS = 8000L
        private const val GPS_CAMERA_BRIDGE_START_MS = 1500L
        private const val GPS_CAMERA_BRIDGE_MAX_MS = 12_000L
        private const val CAMERA_SEARCH_M = 2300f
        private const val CAMERA_CONFIRM_EXTRA_M = 500f
        private const val CAMERA_CLUSTER_BASE_M = 40f
        private const val CAMERA_CLUSTER_EXTENDED_M = 110f
        private const val CAMERA_CLUSTER_AXIS_DELTA_DEG = 18f
        private const val CAMERA_CLUSTER_DIRECTED_DELTA_DEG = 22f
        private const val CAMERA_DIAG_NEAR_M = 950f
        private const val CAMERA_DIAG_INTERVAL_MS = 5000L
        private const val PASS_BEHIND_DEG = 100f
        private const val PASS_DISTANCE_GROWTH_M = 25f
        private const val NEAR_PASS_AUDIT_M = 140f
        private const val GLOBAL_ALERT_MIN_GAP_MS = 350L
        private const val FIRST_ALERT_FORCE_MS = 1200L
    }

    // Inputs of the fix/bridge currently being evaluated. Same names as in LocationService,
    // so the moved functions below are textually identical to the field-validated code.
    private var latestLat = Double.NaN
    private var latestLon = Double.NaN
    private var latestBearing = -1f
    private var latestBearingValid = false
    private var latestAccuracy = -1f
    private var latestSpeedKmh = 0f
    private var recoveredLocationGapMs = 0L

    private var globalLastCameraPulseElapsed = 0L
    private var globalLastCameraKey = ""

    private val cameraStates = HashMap<String, CameraTrackState>()

    val cameraClusters: List<CameraCluster> = buildCameraClusters(cameras)

    /** Read-only view used by LocationService for CSV columns, UI and gap recovery. */
    val trackStates: Map<String, CameraTrackState> get() = cameraStates

    private fun distanceM(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
        val results = FloatArray(1)
        geo.distanceBetween(lat1, lon1, lat2, lon2, results)
        return results[0]
    }

    private fun buildCameraClusters(input: List<CameraPoint>): List<CameraCluster> {
        val remaining = input.toMutableList()
        val output = ArrayList<CameraCluster>()

        while (remaining.isNotEmpty()) {
            val seed = remaining.removeAt(0)
            val members = mutableListOf(seed)

            var changed = true
            while (changed) {
                changed = false
                val iterator = remaining.iterator()
                while (iterator.hasNext()) {
                    val candidate = iterator.next()
                    if (members.any { camerasClusterCompatible(it, candidate) }) {
                        members += candidate
                        iterator.remove()
                        changed = true
                    }
                }
            }

            val representative = members.maxByOrNull { cameraMetadataScore(it) } ?: seed
            val averageLat = members.map { it.latitude }.average()
            val averageLon = members.map { it.longitude }.average()
            val synthetic = representative.copy(latitude = averageLat, longitude = averageLon)
            val ids = members.map { it.id }.distinct().sorted()

            output += CameraCluster(
                key = representative.type + ":" + ids.joinToString("+"),
                camera = synthetic,
                memberIds = ids
            )
        }

        return output
    }

    private fun camerasClusterCompatible(a: CameraPoint, b: CameraPoint): Boolean {
        if (a.type != b.type) return false

        val results = FloatArray(1)
        geo.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, results)
        val distance = results[0]
        if (distance > CAMERA_CLUSTER_EXTENDED_M) return false

        val aRb = a.roadBearing
        val bRb = b.roadBearing

        if (distance <= CAMERA_CLUSTER_BASE_M) {
            if (aRb == null || bRb == null) return true
            return bearingsClusterCompatible(a, b)
        }

        // Extended clustering is deliberately strict: it exists only to collapse
        // duplicate database records for one physical camera, not nearby distinct cameras.
        if (aRb == null || bRb == null) return false
        if (!bearingsClusterCompatible(a, b)) return false

        val aLimit = a.speedLimit
        val bLimit = b.speedLimit
        if (aLimit != null && bLimit != null && abs(aLimit - bLimit) > 5) return false

        val aRoad = normalizeRoadName(a.roadName)
        val bRoad = normalizeRoadName(b.roadName)
        if (aRoad.isNotBlank() && bRoad.isNotBlank() && aRoad != bRoad) return false

        return true
    }

    private fun bearingsClusterCompatible(a: CameraPoint, b: CameraPoint): Boolean {
        val aRb = a.roadBearing ?: return true
        val bRb = b.roadBearing ?: return true
        val aDirected = hasReliableDirectedBearing(a)
        val bDirected = hasReliableDirectedBearing(b)

        return if (aDirected && bDirected) {
            angleDifference(aRb, bRb) <= CAMERA_CLUSTER_DIRECTED_DELTA_DEG
        } else {
            val axisDelta = min(
                angleDifference(aRb, bRb),
                angleDifference(aRb, normalizeBearing(bRb + 180f))
            )
            axisDelta <= CAMERA_CLUSTER_AXIS_DELTA_DEG
        }
    }

    private fun normalizeRoadName(value: String): String =
        value.trim().lowercase(Locale.US).replace(Regex("\\s+"), " ")

    private fun hasReliableDirectedBearing(camera: CameraPoint): Boolean {
        if (!camera.oneway || camera.roadBearing == null) return false
        val confidence = camera.directionConfidence.lowercase(Locale.US)
        return confidence == "high" || confidence == "medium"
    }

    private fun cameraMetadataScore(camera: CameraPoint): Int {
        var score = 0
        if (validDynamicLimit(camera) != null) score += 5
        if (camera.roadBearing != null) score += 3
        when (camera.directionConfidence.lowercase(Locale.US)) {
            "high" -> score += 3
            "medium" -> score += 2
        }
        if ((camera.roadDistanceM ?: 999.0) <= 30.0) score += 2
        if (camera.roadName.isNotBlank()) score += 1
        return score
    }

    fun evaluateAllCameras(fix: CameraFix): CameraEvaluation {
        latestLat = fix.lat
        latestLon = fix.lon
        latestBearing = fix.bearingDeg
        latestBearingValid = true
        latestAccuracy = fix.accuracyM
        latestSpeedKmh = fix.speedKmh
        recoveredLocationGapMs = fix.recoveredLocationGapMs

        val now = fix.nowElapsedMs

        val confirmedGeometries = ArrayList<CameraGeometry>()
        val alertRequests = ArrayList<AlertRequest>()

        for (cluster in cameraClusters) {
            val camera = cluster.camera
            val directDistance = distanceM(latestLat, latestLon, camera.latitude, camera.longitude)
            if (directDistance > CAMERA_SEARCH_M) continue

            var state = cameraStates.getOrPut(cluster.key) { CameraTrackState() }

            if (
                (state.phase == TrackPhase.PASSED || state.phase == TrackPhase.ABANDONED) &&
                directDistance > 1200f &&
                now - state.transitionElapsed > 30_000L
            ) {
                state = CameraTrackState()
                cameraStates[cluster.key] = state
            }

            if (state.phase == TrackPhase.PASSED || state.phase == TrackPhase.ABANDONED) {
                state.lastSeenElapsed = now
                continue
            }

            val geometry = buildCameraGeometry(cluster, state, now)
            state.lastSeenElapsed = now
            state.minDistanceM = min(state.minDistanceM, geometry.directDistanceM)
            updateApproachState(state, geometry)

            val withinConfirmRange =
                geometry.directDistanceM <=
                    max(950f, geometry.warningDistanceM + CAMERA_CONFIRM_EXTRA_M)

            val strongApproachHistory = state.approachHits >= 2
            val nearFastTrack =
                geometry.directDistanceM <= 500f &&
                    strongApproachHistory &&
                    geometry.hardGeometryOk &&
                    geometry.matchScore >= geometry.requiredScore - 1

            val confirmEligible =
                withinConfirmRange &&
                    geometry.hardGeometryOk &&
                    (
                        geometry.matchScore >= geometry.requiredScore ||
                            nearFastTrack
                    ) &&
                    (
                        state.approachHits >= 1 ||
                            geometry.directDistanceM <= 250f
                    )

            if (state.phase == TrackPhase.TRACKING) {
                if (confirmEligible) {
                    state.confirmHits++
                    val hitsNeeded = if (nearFastTrack) 1 else geometry.requiredHits
                    if (state.confirmHits >= hitsNeeded) {
                        state.phase = TrackPhase.CONFIRMED
                        state.transitionElapsed = now
                        state.hardBadHits = 0
                        host.cameraEvent(
                            "CAMERA_MATCH_CONFIRMED",
                            geometry,
                            state,
                            "confirmHits=${state.confirmHits};hitsNeeded=$hitsNeeded;" +
                                "approachHits=${state.approachHits};fastTrack=$nearFastTrack"
                        )
                    }
                } else {
                    state.confirmHits = max(0, state.confirmHits - 1)
                }
            }

            if (
                state.phase == TrackPhase.TRACKING &&
                geometry.directDistanceM <= CAMERA_DIAG_NEAR_M &&
                now - state.lastDiagElapsed >= CAMERA_DIAG_INTERVAL_MS
            ) {
                state.lastDiagElapsed = now
                host.cameraEvent(
                    "CAMERA_MATCH_DIAG",
                    geometry,
                    state,
                    "reason=${geometry.matchReason};confirmHits=${state.confirmHits};" +
                        "approachHits=${state.approachHits};awayHits=${state.awayHits}"
                )
            }

            if (
                geometry.directDistanceM <= NEAR_PASS_AUDIT_M &&
                !state.nearPassAudited
            ) {
                state.nearPassAudited = true
                host.cameraEvent(
                    "CAMERA_NEAR_PASS_AUDIT",
                    geometry,
                    state,
                    "phase=${state.phase};warned=${state.warned}"
                )
            }

            if (state.phase == TrackPhase.CONFIRMED) {
                state.bridgeLogged = false
                state.lastGeometry = geometry
                state.lastGeometryElapsed = now

                if (geometry.hardGeometryOk) state.hardBadHits = 0 else state.hardBadHits++

                // If a long location gap ended after the camera had already moved behind us,
                // never emit a late beep. Record the miss explicitly instead.
                if (
                    recoveredLocationGapMs > LOCATION_STALE_MS &&
                    geometry.vehicleForwardM <= 0f
                ) {
                    if (!state.warned && !state.missedDuringGapLogged) {
                        state.missedDuringGapLogged = true
                        host.cameraEvent(
                            "CAMERA_MISSED_DURING_GPS_GAP",
                            geometry,
                            state,
                            "gapMs=$recoveredLocationGapMs;minDistance=${String.format(Locale.US, "%.1f", state.minDistanceM)}"
                        )
                    }
                    markCameraPassed(geometry, state, now)
                    state.lastDistanceM = geometry.directDistanceM
                    continue
                }

                val clearlyBehind = geometry.forwardDeltaDeg >= PASS_BEHIND_DEG
                val distanceGrowing =
                    state.lastDistanceM != Float.MAX_VALUE &&
                        geometry.directDistanceM > state.minDistanceM + PASS_DISTANCE_GROWTH_M

                if (clearlyBehind && distanceGrowing) {
                    state.awayHits++
                    if (state.awayHits >= 2) {
                        markCameraPassed(geometry, state, now)
                        state.lastDistanceM = geometry.directDistanceM
                        continue
                    }
                }

                if (
                    state.hardBadHits >= 4 &&
                    state.awayHits >= 3 &&
                    geometry.directDistanceM > 250f
                ) {
                    state.phase = TrackPhase.ABANDONED
                    state.transitionElapsed = now
                    state.alertLevel = 0
                    host.cameraEvent(
                        "CAMERA_ABANDONED",
                        geometry,
                        state,
                        "reason=hard_geometry_failed_while_moving_away;hardBadHits=${state.hardBadHits}"
                    )
                    state.lastDistanceM = geometry.directDistanceM
                    continue
                }

                if (geometry.vehicleForwardM > 0f && geometry.forwardDeltaDeg < PASS_BEHIND_DEG) {
                    confirmedGeometries += geometry
                }

                computeAlertRequest(geometry, state, false)?.let { alertRequests += it }
            }

            state.lastDistanceM = geometry.directDistanceM
        }

        return CameraEvaluation(confirmedGeometries, alertRequests)
    }

    private fun markCameraPassed(
        geometry: CameraGeometry,
        state: CameraTrackState,
        now: Long
    ) {
        host.cameraEvent(
            "CAMERA_PASSED",
            geometry,
            state,
            "warned=${state.warned};minDistance=${String.format(Locale.US, "%.1f", state.minDistanceM)}"
        )

        if (!state.warned && state.minDistanceM <= NEAR_PASS_AUDIT_M) {
            host.cameraEvent(
                "CAMERA_MISSED_DIAGNOSTIC",
                geometry,
                state,
                "physically_near_camera_but_no_warning=true"
            )
        }

        state.phase = TrackPhase.PASSED
        state.transitionElapsed = now
        state.alertLevel = 0
    }

    private fun buildCameraGeometry(
        cluster: CameraCluster,
        state: CameraTrackState,
        now: Long
    ): CameraGeometry {
        val camera = cluster.camera
        val results = FloatArray(2)
        geo.distanceBetween(latestLat, latestLon, camera.latitude, camera.longitude, results)
        val distance = results[0]
        val bearingToCamera = normalizeBearing(results[1])
        val forwardDelta = angleDifference(latestBearing, bearingToCamera)

        val vehicleForward =
            (distance * cos(Math.toRadians(forwardDelta.toDouble()))).toFloat()
        val vehicleCross =
            abs(distance * sin(Math.toRadians(forwardDelta.toDouble()))).toFloat()

        val rb = camera.roadBearing
        val roadAxisDelta =
            if (rb != null) {
                min(
                    angleDifference(latestBearing, normalizeBearing(rb)),
                    angleDifference(latestBearing, normalizeBearing(rb + 180f))
                )
            } else {
                0f
            }

        val roadDirectionDelta =
            if (rb != null) {
                if (hasReliableDirectedBearing(camera)) {
                    angleDifference(latestBearing, normalizeBearing(rb))
                } else {
                    roadAxisDelta
                }
            } else {
                0f
            }

        val roadCross =
            if (rb != null) {
                val cameraAxisDelta = min(
                    angleDifference(normalizeBearing(rb), bearingToCamera),
                    angleDifference(normalizeBearing(rb + 180f), bearingToCamera)
                )
                abs(
                    distance * sin(Math.toRadians(cameraAxisDelta.toDouble()))
                ).toFloat()
            } else {
                vehicleCross
            }

        // Curve-aware cross-track: a curved road can make the camera-road tangent and
        // the car's instantaneous heading disagree strongly at long range. We hard-reject
        // only when BOTH independent cross-track views are bad. Score can never override it.
        val curveCross = if (rb != null) min(vehicleCross, roadCross) else vehicleCross

        val baseHardCrossLimit =
            when {
                distance > 1500f -> 230f
                distance > 1100f -> 210f
                distance > 800f -> 195f
                distance > 600f -> 178f
                distance > 450f -> 145f
                distance > 300f -> 115f
                else -> 80f
            }

        val accuracyAllowance =
            if (latestAccuracy >= 0f) (latestAccuracy * 1.2f).coerceIn(0f, 20f) else 10f
        val hardCrossLimit = baseHardCrossLimit + accuracyAllowance
        val hardCrossOk = curveCross <= hardCrossLimit

        val forwardLimit =
            when {
                distance > 1100f -> 45f
                distance > 750f -> 50f
                distance > 550f -> 55f
                distance > 350f -> 68f
                else -> 85f
            }

        val roadDirectionLimit =
            when {
                distance > 1100f -> 42f
                distance > 750f -> 48f
                distance > 550f -> 55f
                distance > 350f -> 65f
                else -> 78f
            }

        val directionGateOk =
            forwardDelta <= forwardLimit &&
                (
                    rb == null ||
                        roadDirectionDelta <= roadDirectionLimit
                    )

        val hardGeometryOk =
            vehicleForward > 8f &&
                hardCrossOk &&
                directionGateOk

        val candidateLimit = if (camera.type == "speed") validDynamicLimit(camera) else null
        val warningDistance = computeAdaptiveWarningDistanceM(
            latestSpeedKmh,
            candidateLimit,
            camera.type
        )

        val speedMps = max(1.5f, latestSpeedKmh / 3.6f)
        val ttc = if (vehicleForward > 0f) vehicleForward / speedMps else -1f

        val dtS =
            if (state.lastSeenElapsed > 0L) {
                (now - state.lastSeenElapsed).coerceAtLeast(1L) / 1000f
            } else {
                0f
            }

        val approachDelta =
            if (state.lastDistanceM != Float.MAX_VALUE) state.lastDistanceM - distance else 0f
        val approachRate = if (dtS > 0f) approachDelta / dtS else 0f

        var score = 0
        val reasons = ArrayList<String>()

        if (!hardCrossOk) {
            reasons += "hard_curve_cross"
        } else {
            when {
                curveCross <= hardCrossLimit * 0.35f -> score += 3
                curveCross <= hardCrossLimit * 0.65f -> score += 2
                else -> score += 1
            }
        }

        when {
            forwardDelta <= 20f -> score += 3
            forwardDelta <= 35f -> score += 2
            forwardDelta <= 55f -> score += 1
            else -> reasons += if (forwardDelta >= PASS_BEHIND_DEG) "behind_vehicle" else "forward_angle"
        }

        if (rb != null) {
            when {
                roadDirectionDelta <= 20f -> score += 2
                roadDirectionDelta <= 40f -> score += 1
                else -> reasons += if (hasReliableDirectedBearing(camera)) "road_direction" else "road_axis"
            }
        } else {
            score += 1
        }

        if (vehicleForward > 8f) score += 1 else reasons += "not_ahead"

        if (approachDelta > 2f) {
            score += 2
        } else if (approachDelta < -3f) {
            reasons += "moving_away"
        }

        when {
            latestAccuracy in 0f..8f -> score += 2
            latestAccuracy in 0f..18f -> score += 1
        }

        if (!directionGateOk && forwardDelta < PASS_BEHIND_DEG) {
            reasons += "direction_gate"
        }

        val requiredScore =
            when {
                distance > 1200f -> 9
                distance > 850f -> 8
                distance > 550f -> 7
                distance > 320f -> 6
                else -> 5
            }

        val requiredHits =
            when {
                distance > 850f -> 3
                distance > 600f -> 3
                distance > 350f -> 2
                else -> 1
            }

        return CameraGeometry(
            cluster = cluster,
            directDistanceM = distance,
            vehicleForwardM = vehicleForward,
            vehicleCrossM = vehicleCross,
            bearingToCameraDeg = bearingToCamera,
            forwardDeltaDeg = forwardDelta,
            roadCrossM = roadCross,
            curveCrossM = curveCross,
            roadAxisDeltaDeg = roadAxisDelta,
            roadDirectionDeltaDeg = roadDirectionDelta,
            hardCrossLimitM = hardCrossLimit,
            hardCrossOk = hardCrossOk,
            directionGateOk = directionGateOk,
            hardGeometryOk = hardGeometryOk,
            warningDistanceM = warningDistance,
            ttcS = ttc,
            candidateLimit = candidateLimit,
            approachDeltaM = approachDelta,
            approachRateMps = approachRate,
            matchScore = score,
            requiredScore = requiredScore,
            requiredHits = requiredHits,
            matchReason = if (reasons.isEmpty()) "good" else reasons.distinct().joinToString("+")
        )
    }

    private fun updateApproachState(state: CameraTrackState, geometry: CameraGeometry) {
        if (state.lastDistanceM == Float.MAX_VALUE) return
        when {
            geometry.approachDeltaM > 2f -> {
                state.approachHits = min(10, state.approachHits + 1)
                state.awayHits = max(0, state.awayHits - 1)
            }
            geometry.approachDeltaM < -3f -> {
                state.awayHits = min(10, state.awayHits + 1)
                state.approachHits = max(0, state.approachHits - 1)
            }
        }
    }

    fun computeAlertRequest(
        geometry: CameraGeometry,
        state: CameraTrackState,
        bridge: Boolean
    ): AlertRequest? {
        if (state.phase != TrackPhase.CONFIRMED) return null
        if (geometry.vehicleForwardM <= 0f || geometry.forwardDeltaDeg >= PASS_BEHIND_DEG) {
            state.alertLevel = 0
            return null
        }

        // Hard geometry is never rescued by score. The cross-track itself is now curve-aware.
        if (!geometry.hardGeometryOk) {
            state.alertLevel = 0
            return null
        }

        val inWarningZone = geometry.vehicleForwardM <= geometry.warningDistanceM + 90f
        if (!inWarningZone) {
            state.alertLevel = 0
            return null
        }

        // BEGIN V0.15 GUARDED NEGATIVE ROUTE VETO
        // Deliberately narrow live influence. Generic support/conflict/outside-coverage
        // remains diagnostic-only. We veto only a FIRST, non-bridged alert when the vehicle
        // is on an explicitly user-confirmed false-warning route and both position + heading
        // match that route. Once an alert has started, geometry cannot mute it.
        if (!bridge && !state.warned) {
            val explicitNegative = try {
                host.explicitNegativeRoute(
                    geometry.cluster.memberIds,
                    geometry.cluster.camera.type,
                    latestLat,
                    latestLon,
                    if (latestBearingValid) latestBearing else null
                )
            } catch (_: Exception) {
                null
            }

            if (
                explicitNegative?.verdict == "negative_route" &&
                explicitNegative.evidenceKind == "explicit_negative"
            ) {
                state.alertLevel = 0
                if (!state.explicitNegativeSuppressionLogged) {
                    state.explicitNegativeSuppressionLogged = true
                    host.cameraEvent(
                        "CAMERA_NEGATIVE_ROUTE_SUPPRESSED",
                        geometry,
                        state,
                        "negativeLabel=${explicitNegative.negativeLabel ?: ""};" +
                            "negativeDistanceM=${String.format(Locale.US, "%.1f", explicitNegative.corridorDistanceM)};" +
                            "negativeHeadingDelta=${String.format(Locale.US, "%.1f", explicitNegative.headingDeltaDeg)};" +
                            "bridge=$bridge;policy=${host.negativeRoutePolicy}"
                    )
                }
                return null
            }
        }
        // END V0.15 GUARDED NEGATIVE ROUTE VETO
        val level = computeCameraAlertLevel(
            geometry.vehicleForwardM,
            geometry.ttcS,
            latestSpeedKmh,
            geometry.candidateLimit,
            geometry.warningDistanceM
        )
        state.alertLevel = level

        if (!state.warned) {
            state.warned = true
            state.warningStartedElapsed = clock()
            host.cameraEvent(
                "CAMERA_WARNING",
                geometry,
                state,
                "first_warning=true;level=$level;bridge=$bridge"
            )
        }

        if (level >= 3 && !state.urgentLogged) {
            state.urgentLogged = true
            host.cameraEvent(
                "CAMERA_URGENT",
                geometry,
                state,
                "level=$level;bridge=$bridge"
            )
        }

        return AlertRequest(geometry, state, level, bridge)
    }

    fun dispatchCameraAlerts(requests: List<AlertRequest>) {
        if (requests.isEmpty()) return
        val now = clock()

        val sorted = requests.sortedWith(
            compareByDescending<AlertRequest> { it.level }
                .thenBy { if (it.geometry.ttcS > 0f) it.geometry.ttcS else Float.MAX_VALUE }
                .thenBy { it.geometry.vehicleForwardM }
        )

        // Guarantee the FIRST audible alert for every confirmed physical cluster.
        // Arbitration may delay it briefly to avoid overlapping tones, but can no longer
        // suppress it for tens of seconds as happened in 0.9.
        val pendingFirst = sorted.filter { !it.state.firstAlertDelivered }
        if (pendingFirst.isNotEmpty()) {
            val chosen = pendingFirst.first()
            val pendingAge = now - chosen.state.warningStartedElapsed
            val globalGap = now - globalLastCameraPulseElapsed
            if (globalGap >= GLOBAL_ALERT_MIN_GAP_MS || pendingAge >= FIRST_ALERT_FORCE_MS) {
                globalLastCameraPulseElapsed = now
                globalLastCameraKey = chosen.geometry.cluster.key
                chosen.state.firstAlertDelivered = true
                chosen.state.lastPulseElapsed = now
                host.cameraAlertOutput(
                    chosen,
                    max(0, requests.size - 1),
                    true
                )
                return
            }
        }

        val repeatCandidates = sorted.filter {
            val interval = alertRepeatIntervalMs(it.level)
            now - it.state.lastPulseElapsed >= interval
        }
        if (repeatCandidates.isEmpty()) return
        if (now - globalLastCameraPulseElapsed < GLOBAL_ALERT_MIN_GAP_MS) return

        val chosen = repeatCandidates.first()
        globalLastCameraPulseElapsed = now
        globalLastCameraKey = chosen.geometry.cluster.key
        chosen.state.lastPulseElapsed = now
        host.cameraAlertOutput(
            chosen,
            max(0, requests.size - 1),
            false
        )
    }

    private fun alertRepeatIntervalMs(level: Int): Long =
        when (level) {
            1 -> 5000L
            2 -> 3000L
            3 -> 1500L
            4 -> 900L
            else -> Long.MAX_VALUE
        }

    fun bridgeConfirmedCameraAlerts(locationAgeMs: Long, speedKmh: Float): List<AlertRequest> {
        latestSpeedKmh = speedKmh
        if (
            locationAgeMs < GPS_CAMERA_BRIDGE_START_MS ||
            locationAgeMs > GPS_CAMERA_BRIDGE_MAX_MS
        ) {
            return emptyList()
        }

        val now = clock()
        val speedMps = max(0f, latestSpeedKmh / 3.6f)
        if (speedMps < 1.0f) return emptyList()

        val requests = ArrayList<AlertRequest>()

        for ((_, state) in cameraStates) {
            if (state.phase != TrackPhase.CONFIRMED) continue
            val last = state.lastGeometry ?: continue
            if (!last.hardGeometryOk) continue

            val elapsedS =
                (now - state.lastGeometryElapsed).coerceAtLeast(0L) / 1000f
            if (elapsedS <= 0f || elapsedS > GPS_CAMERA_BRIDGE_MAX_MS / 1000f) continue

            val predictedForward = last.vehicleForwardM - speedMps * elapsedS
            if (predictedForward <= 0f) {
                if (!state.warned && !state.missedDuringGapLogged) {
                    state.missedDuringGapLogged = true
                    host.cameraEvent(
                        "CAMERA_PREDICTED_PASS_DURING_GPS_GAP",
                        last,
                        state,
                        "locationAgeMs=$locationAgeMs;elapsedS=${String.format(Locale.US, "%.1f", elapsedS)}"
                    )
                }
                continue
            }

            val predictedDirect = max(0f, last.directDistanceM - speedMps * elapsedS)
            val predictedTtc = predictedForward / max(1.5f, speedMps)
            val bridged = last.copy(
                directDistanceM = predictedDirect,
                vehicleForwardM = predictedForward,
                ttcS = predictedTtc,
                approachDeltaM = 0f,
                approachRateMps = speedMps
            )

            if (!state.bridgeLogged) {
                state.bridgeLogged = true
                host.cameraEvent(
                    "CAMERA_GPS_BRIDGE_START",
                    bridged,
                    state,
                    "locationAgeMs=$locationAgeMs;maxBridgeMs=$GPS_CAMERA_BRIDGE_MAX_MS"
                )
            }

            computeAlertRequest(bridged, state, true)?.let { requests += it }
        }

        return requests
    }

    fun cleanupOldCameraStates(now: Long) {
        val iterator = cameraStates.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value.lastSeenElapsed > 180_000L) iterator.remove()
        }
    }

    private fun computeAdaptiveWarningDistanceM(
        speedKmh: Float,
        cameraLimitKmh: Int?,
        cameraType: String
    ): Float {
        val v = max(5f, speedKmh) / 3.6f
        val baseLeadS =
            (24f + (speedKmh - 45f).coerceAtLeast(0f) * 0.12f)
                .coerceIn(24f, 32f)

        var warningM = v * baseLeadS

        if (cameraLimitKmh != null && speedKmh > cameraLimitKmh) {
            val target = cameraLimitKmh / 3.6f
            val decelDistance =
                ((v * v - target * target) / (2f * 1.6f)).coerceAtLeast(0f)
            val reactionDistance = v * 5f
            warningM = max(warningM, decelDistance + reactionDistance + 90f)
        }

        if (cameraType == "red_light") {
            warningM = max(warningM, v * 26f)
        }

        return warningM.coerceIn(440f, 1250f)
    }

    private fun computeCameraAlertLevel(
        forwardM: Float,
        ttcS: Float,
        speedKmh: Float,
        cameraLimitKmh: Int?,
        warningDistanceM: Float
    ): Int {
        val overLimit = cameraLimitKmh != null && speedKmh > cameraLimitKmh + 2f
        return when {
            (ttcS in 0f..6f || forwardM <= 140f) && overLimit -> 4
            ttcS in 0f..9f || forwardM <= 220f -> 3
            ttcS in 0f..15f || forwardM <= min(420f, warningDistanceM * 0.72f) -> 2
            else -> 1
        }
    }

    private fun validDynamicLimit(camera: CameraPoint): Int? {
        val limit = camera.speedLimit ?: return null
        val confidence = camera.speedConfidence.lowercase(Locale.US)
        if (limit !in 20..150) return null
        if (confidence != "high" && confidence != "medium") return null
        if ((camera.roadDistanceM ?: 999.0) > 30.0) return null
        return limit
    }

    private fun normalizeBearing(value: Float): Float {
        var x = value % 360f
        if (x < 0f) x += 360f
        return x
    }

    private fun angleDifference(a: Float, b: Float): Float {
        var d = abs(a - b) % 360f
        if (d > 180f) d = 360f - d
        return d
    }

    /** Camera part of LocationService.prepareForLocationGapRecovery(), verbatim. */
    fun resetTrackingAfterLocationGap() {
        for ((_, state) in cameraStates) {
            state.lastDistanceM = Float.MAX_VALUE
            state.awayHits = 0
            state.hardBadHits = 0
            if (state.phase == TrackPhase.TRACKING) {
                state.confirmHits = 0
                state.approachHits = 0
            }
        }
    }
}
