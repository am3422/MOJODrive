package com.mojotech.mojodrive

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * JVM port of android.location.Location.computeDistanceAndBearing (AOSP, Apache-2.0):
 * Vincenty inverse formula on the WGS84 ellipsoid, max 20 iterations, results narrowed
 * to Float exactly like the platform. On the phone the app calls the real
 * Location.distanceBetween; unit tests use this port so the replay sees the same numbers.
 *
 * results[0] = distance in meters, results[1] = initial bearing, results[2] = final bearing.
 */
object AospGeodesy : Geodesy {

    override fun distanceBetween(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double,
        results: FloatArray
    ) {
        require(results.isNotEmpty()) { "results is null or has length < 1" }

        val maxIters = 20
        val rLat1 = lat1 * (Math.PI / 180.0)
        val rLat2 = lat2 * (Math.PI / 180.0)
        val rLon1 = lon1 * (Math.PI / 180.0)
        val rLon2 = lon2 * (Math.PI / 180.0)

        val a = 6378137.0 // WGS84 major axis
        val b = 6356752.3142 // WGS84 semi-minor axis
        val f = (a - b) / a
        val aSqMinusBSqOverBSq = (a * a - b * b) / (b * b)

        val l = rLon2 - rLon1
        var aa = 0.0
        val u1 = atan((1.0 - f) * tan(rLat1))
        val u2 = atan((1.0 - f) * tan(rLat2))

        val cosU1 = cos(u1)
        val cosU2 = cos(u2)
        val sinU1 = sin(u1)
        val sinU2 = sin(u2)
        val cosU1cosU2 = cosU1 * cosU2
        val sinU1sinU2 = sinU1 * sinU2

        var sigma = 0.0
        var deltaSigma = 0.0
        var cosSqAlpha: Double
        var cos2SM: Double
        var cosSigma: Double
        var sinSigma: Double
        var cosLambda = 0.0
        var sinLambda = 0.0

        var lambda = l // initial guess
        for (iter in 0 until maxIters) {
            val lambdaOrig = lambda
            cosLambda = cos(lambda)
            sinLambda = sin(lambda)
            val t1 = cosU2 * sinLambda
            val t2 = cosU1 * sinU2 - sinU1 * cosU2 * cosLambda
            val sinSqSigma = t1 * t1 + t2 * t2
            sinSigma = sqrt(sinSqSigma)
            cosSigma = sinU1sinU2 + cosU1cosU2 * cosLambda
            sigma = atan2(sinSigma, cosSigma)
            val sinAlpha = if (sinSigma == 0.0) 0.0 else cosU1cosU2 * sinLambda / sinSigma
            cosSqAlpha = 1.0 - sinAlpha * sinAlpha
            cos2SM = if (cosSqAlpha == 0.0) 0.0 else cosSigma - 2.0 * sinU1sinU2 / cosSqAlpha

            val uSquared = cosSqAlpha * aSqMinusBSqOverBSq
            aa = 1 + (uSquared / 16384.0) *
                (4096.0 + uSquared * (-768 + uSquared * (320.0 - 175.0 * uSquared)))
            val bb = (uSquared / 1024.0) *
                (256.0 + uSquared * (-128.0 + uSquared * (74.0 - 47.0 * uSquared)))
            val c = (f / 16.0) * cosSqAlpha * (4.0 + f * (4.0 - 3.0 * cosSqAlpha))
            val cos2SMSq = cos2SM * cos2SM
            deltaSigma = bb * sinSigma *
                (cos2SM + (bb / 4.0) *
                    (cosSigma * (-1.0 + 2.0 * cos2SMSq) -
                        (bb / 6.0) * cos2SM *
                        (-3.0 + 4.0 * sinSigma * sinSigma) *
                        (-3.0 + 4.0 * cos2SMSq)))

            lambda = l +
                (1.0 - c) * f * sinAlpha *
                (sigma + c * sinSigma *
                    (cos2SM + c * cosSigma * (-1.0 + 2.0 * cos2SM * cos2SM)))

            val delta = (lambda - lambdaOrig) / lambda
            if (abs(delta) < 1.0e-12) break
        }

        results[0] = (b * aa * (sigma - deltaSigma)).toFloat()
        if (results.size > 1) {
            var initialBearing = atan2(
                cosU2 * sinLambda,
                cosU1 * sinU2 - sinU1 * cosU2 * cosLambda
            ).toFloat()
            initialBearing = (initialBearing * (180.0 / Math.PI)).toFloat()
            results[1] = initialBearing
            if (results.size > 2) {
                var finalBearing = atan2(
                    cosU1 * sinLambda,
                    -sinU1 * cosU2 + cosU1 * sinU2 * cosLambda
                ).toFloat()
                finalBearing = (finalBearing * (180.0 / Math.PI)).toFloat()
                results[2] = finalBearing
            }
        }
    }
}
