package com.mojotech.mojodrive

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The v0.15 guarded live veto, tested on the real engine with the 2026-09-28 field trip.
 * Only explicit, human-confirmed negative-route evidence may suppress a FIRST warning;
 * generic road-geometry verdicts must never change an alert.
 */
class NegativeRouteVetoTest {

    private val trip = "v014_trip_20260928_094832_locations.csv"
    private val cameras = TripReplay.loadCameraSnapshot().second
    private val baseline = TripReplay.replay(trip, cameras)

    private fun evidence(verdict: String, kind: String) =
        NegativeRouteEvidence(verdict, kind, "test_label", 0f, 0f)

    @Test
    fun explicitNegativeRouteSuppressesOnlyThatCamerasFirstWarning() {
        val result = TripReplay.replay(trip, cameras, negativeRoutes = { ids ->
            if ("14550" in ids) evidence("negative_route", "explicit_negative") else null
        })
        val expected = baseline.firstWarnings.filterNot { it.contains("14550") }
        assertTrue("trip must contain a 14550 warning to test the veto", baseline.firstWarnings.any { it.contains("14550") })
        assertEquals("only 14550 may lose its first warning", expected, result.firstWarnings)
        assertEquals("suppression must be logged exactly once", 1, result.count("CAMERA_NEGATIVE_ROUTE_SUPPRESSED"))
        assertTrue("no beep for the vetoed camera", result.outputs.none { it.clusterKey.contains("14550") })
    }

    @Test
    fun genericRoadGeometryVerdictsNeverChangeAlerts() {
        for (verdict in listOf("conflict", "outside_coverage", "uncertain", "support", "weak_support")) {
            val result = TripReplay.replay(trip, cameras, negativeRoutes = { evidence(verdict, "positive") })
            assertEquals("verdict=$verdict changed warnings", baseline.firstWarnings, result.firstWarnings)
            assertEquals("verdict=$verdict changed beeps", baseline.outputs, result.outputs)
        }
        // negative_route without explicit evidence kind is not enough either
        val notExplicit = TripReplay.replay(trip, cameras, negativeRoutes = { evidence("negative_route", "learned") })
        assertEquals("negative_route without explicit evidence changed beeps", baseline.outputs, notExplicit.outputs)
    }

    @Test
    fun vetoIsNeverConsultedAfterAWarningStarted() {
        // Once a camera has warned, road geometry can never mute it: the engine stops asking.
        var now = 0L
        val host = TripReplay.RecordingHost { now }
        val engine = CameraEngine(cameras, AospGeodesy, host) { now }
        val rows = TripReplay.loadLocationRows(TripReplay.fixture(trip))
        for (row in rows) {
            now = row.wallTimeMs
            if (row.locationGapMs >= 3000L) engine.resetTrackingAfterLocationGap()
            val bearing = row.bearingDeg ?: continue
            if (!row.bearingValid) continue
            val before = host.negativeRouteQueries.size
            val warnedBefore = engine.trackStates.filterValues { it.warned && it.phase == TrackPhase.CONFIRMED }.keys
            val r = engine.evaluateAllCameras(CameraFix(now, row.lat, row.lon, bearing, row.accuracyM, row.speedKmh, row.locationGapMs))
            val asked = host.negativeRouteQueries.subList(before, host.negativeRouteQueries.size)
            for (req in r.alertRequests) {
                if (req.geometry.cluster.key in warnedBefore) {
                    assertTrue("veto consulted for already-warned ${req.geometry.cluster.key}",
                        asked.none { it == req.geometry.cluster.memberIds })
                }
            }
            engine.dispatchCameraAlerts(r.alertRequests)
            engine.cleanupOldCameraStates(now)
        }
    }
}
