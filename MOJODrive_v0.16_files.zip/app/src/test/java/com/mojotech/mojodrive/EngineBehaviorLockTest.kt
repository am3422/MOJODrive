package com.mojotech.mojodrive

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Behavior lock for the camera engine — the strict replacement for the old function-hash guard.
 *
 * tools/fixtures/engine_decisions_v015.tsv was produced by running the ORIGINAL field-validated
 * v0.15 LocationService camera code over every golden trip (with and without the 500 ms
 * GPS-bridge ticker). It records every decision: confirm, warning, every beep with its level,
 * urgent, bridge start, pass, abandon, near-pass audit — 2,277 rows.
 *
 * CameraEngine must reproduce that timeline row for row. The first-warning golden test alone
 * is not enough: a deliberately changed hard-cross limit still passed it, but changes this file.
 *
 * If a FUTURE version intentionally changes engine behavior, regenerate the lock with
 *   MOJO_UPDATE_ENGINE_LOCK=1 gradle :app:testDebugUnitTest
 * and review the diff of the .tsv in the pull request: that diff IS the behavior change.
 */
class EngineBehaviorLockTest {

    private val lockFile: File = TripReplay.fixture("engine_decisions_v015.tsv")

    private fun currentTimeline(): List<String> {
        val (_, cameras) = TripReplay.loadCameraSnapshot()
        val (_, golden) = TripReplay.loadGolden()
        val lines = ArrayList<String>()
        for (ticker in listOf(false, true)) {
            for (trip in golden.keys) {
                lines += TripReplay.replay(trip, cameras, emulateHealthTicker = ticker).decisionLines(ticker)
            }
        }
        return lines
    }

    @Test
    fun engineReproducesTheLockedDecisionTimelineExactly() {
        val actual = currentTimeline()

        if (System.getenv("MOJO_UPDATE_ENGINE_LOCK") == "1") {
            val header = lockFile.readLines(Charsets.UTF_8).takeWhile { it.startsWith("#") }
            lockFile.writeText((header + actual).joinToString("\n") + "\n", Charsets.UTF_8)
            println("ENGINE LOCK REGENERATED: ${actual.size} rows — review the diff before merging")
            return
        }

        val expected = lockFile.readLines(Charsets.UTF_8).filter { it.isNotEmpty() && !it.startsWith("#") }
        val firstDiff = (0 until maxOf(expected.size, actual.size)).firstOrNull {
            expected.getOrNull(it) != actual.getOrNull(it)
        }
        assertTrue(
            "Camera engine behavior changed (row ${firstDiff?.plus(1)} of ${expected.size}):\n" +
                "  locked  : ${firstDiff?.let { expected.getOrNull(it) }}\n" +
                "  current : ${firstDiff?.let { actual.getOrNull(it) }}\n" +
                "If this change is intentional, regenerate the lock (see class comment).",
            firstDiff == null
        )
        println("ENGINE BEHAVIOR LOCK: PASS — ${expected.size}/${expected.size} decision rows identical")
    }
}
