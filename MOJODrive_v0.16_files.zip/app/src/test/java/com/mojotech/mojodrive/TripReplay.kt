package com.mojotech.mojodrive

import java.io.File

/**
 * Replays recorded LOCATION rows through the REAL CameraEngine (the same class the app runs).
 *
 * It mirrors exactly what LocationService does for every accepted location fix:
 *   1. a location gap >= 3 s first resets transient camera tracking (prepareForLocationGapRecovery)
 *   2. if the bearing is not valid, cameras are not evaluated (evaluateAllCameras early return)
 *   3. evaluateAllCameras(fix) -> dispatchCameraAlerts(requests) -> cleanupOldCameraStates(now)
 *
 * Inputs are the values the app logged on that row: position, bearing, accuracy, fused speed.
 * Optionally the 500 ms health ticker is emulated so the confirmed-camera GPS bridge runs too.
 */
object TripReplay {

    private const val LOCATION_RECOVERY_RESET_MS = 3000L // same as LocationService
    private const val GPS_CAMERA_BRIDGE_START_MS = 1500L
    private const val GPS_CAMERA_BRIDGE_MAX_MS = 12_000L
    private const val HEALTH_TICK_MS = 500L

    data class Event(
        val timeMs: Long,
        val type: String,
        val clusterKey: String,
        val phase: TrackPhase,
        val warned: Boolean,
        val directM: Float,
        val forwardM: Float,
        val extra: String
    )

    data class Output(val timeMs: Long, val clusterKey: String, val level: Int, val first: Boolean, val bridge: Boolean)

    data class Result(
        val trip: String,
        val fixes: Int,
        val events: List<Event>,
        val outputs: List<Output>
    ) {
        /** Cluster keys of CAMERA_WARNING events, in order: the "first warning" sequence. */
        val firstWarnings: List<String> get() = events.filter { it.type == "CAMERA_WARNING" }.map { it.clusterKey }
        fun count(type: String) = events.count { it.type == type }

        /**
         * Decision timeline used by the behavior lock (tools/fixtures/engine_decisions_v015.tsv):
         * every camera decision event with its time, camera cluster, phase and warned flag, plus
         * level / first-alert / bridge for every beep. Periodic CAMERA_MATCH_DIAG rows and
         * floating-point measurements are left out so the lock is exact and platform-stable.
         */
        fun decisionLines(ticker: Boolean): List<String> = events.filter { it.type != "CAMERA_MATCH_DIAG" }.map { e ->
            val extra = if (e.type == "ALERT_OUTPUT") e.extra else ""
            listOf(trip, if (ticker) "ticker" else "fixes", e.timeMs.toString(), e.type, e.clusterKey,
                e.phase.name, e.warned.toString(), extra).joinToString("\t")
        }
    }

    data class LocationRow(
        val wallTimeMs: Long,
        val lat: Double,
        val lon: Double,
        val bearingDeg: Float?,
        val bearingValid: Boolean,
        val accuracyM: Float,
        val speedKmh: Float,
        val locationGapMs: Long
    )

    // ---------------------------------------------------------------- repository files

    val repoRoot: File by lazy {
        var dir: File? = File("").absoluteFile
        while (dir != null && !File(dir, "tools/golden_v012_replay.json").exists()) dir = dir.parentFile
        requireNotNull(dir) { "repository root (tools/golden_v012_replay.json) not found" }
    }

    fun fixture(name: String) = File(repoRoot, "tools/fixtures/$name")

    /** Cameras exactly as CameraDatabase.loadAll() returns them (see tools/export_camera_snapshot.py). */
    fun loadCameraSnapshot(): Pair<String, List<CameraPoint>> {
        val lines = fixture("camera_db_snapshot.tsv").readLines(Charsets.UTF_8)
        val sha = lines.first().substringAfter("camera_db_sha256=").trim()
        val cameras = lines.filter { it.isNotEmpty() && !it.startsWith("#") }.map { line ->
            val c = line.split('\t')
            require(c.size == 14) { "bad snapshot row: $line" }
            fun n(i: Int) = if (c[i] == "\\N") null else c[i]
            CameraPoint(
                id = c[0],
                type = c[1],
                latitude = c[2].toDouble(),
                longitude = c[3].toDouble(),
                speedLimit = n(4)?.toInt(),
                roadName = c[5],
                roadHighway = c[6],
                roadDistanceM = n(7)?.toDouble(),
                speedSource = c[8],
                speedConfidence = c[9],
                roadBearing = n(10)?.toDouble()?.toFloat(), // Cursor.getFloat narrows the REAL
                oneway = c[11] == "true",
                directionMode = c[12],
                directionConfidence = c[13]
            )
        }
        return sha to cameras
    }

    /** Minimal reader for tools/golden_v012_replay.json (no JSON library needed). */
    fun loadGolden(): Pair<String, LinkedHashMap<String, List<String>>> {
        val json = File(repoRoot, "tools/golden_v012_replay.json").readText(Charsets.UTF_8)
        val sha = Regex("\"camera_db_sha256\"\\s*:\\s*\"([0-9a-f]+)\"").find(json)!!.groupValues[1]
        val tripsBody = json.substringAfter("\"trips\"")
        val trips = LinkedHashMap<String, List<String>>()
        Regex("\"([^\"]+\\.csv)\"\\s*:\\s*\\[(.*?)]", RegexOption.DOT_MATCHES_ALL).findAll(tripsBody).forEach { m ->
            trips[m.groupValues[1]] = Regex("\"([^\"]+)\"").findAll(m.groupValues[2]).map { it.groupValues[1] }.toList()
        }
        require(trips.isNotEmpty()) { "no trips in golden file" }
        return sha to trips
    }

    fun loadLocationRows(file: File): List<LocationRow> {
        val lines = file.readLines(Charsets.UTF_8)
        val header = parseCsvLine(lines.first())
        fun col(name: String) = header.indexOf(name).also { require(it >= 0) { "missing column $name" } }
        val iType = col("record_type"); val iTime = col("wall_time_ms"); val iLat = col("lat")
        val iLon = col("lon"); val iBearing = col("bearing_deg"); val iBearingValid = col("bearing_valid")
        val iAcc = col("gps_accuracy_m"); val iSpeed = col("fused_speed_kmh"); val iDetails = col("details")
        val gapRegex = Regex("locationGapMs=(\\d+)")

        return lines.drop(1).filter { it.isNotBlank() }.map { parseCsvLine(it) }.filter { r ->
            (r[iType] == "LOCATION" || r[iType] == "LOCATION_ONLY") && r[iLat].isNotEmpty() && r[iLon].isNotEmpty()
        }.map { r ->
            LocationRow(
                wallTimeMs = r[iTime].toLong(),
                lat = r[iLat].toDouble(),
                lon = r[iLon].toDouble(),
                bearingDeg = r[iBearing].takeIf { it.isNotEmpty() }?.toFloat(),
                bearingValid = r[iBearingValid].equals("true", ignoreCase = true),
                accuracyM = r[iAcc].takeIf { it.isNotEmpty() }?.toFloat() ?: -1f,
                speedKmh = r[iSpeed].takeIf { it.isNotEmpty() }?.toFloat() ?: 0f,
                locationGapMs = gapRegex.find(r[iDetails])?.groupValues?.get(1)?.toLong() ?: 0L
            )
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                quoted && ch == '"' && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { out += sb.toString(); sb.setLength(0) }
                else -> sb.append(ch)
            }
            i++
        }
        out += sb.toString()
        return out
    }

    // ---------------------------------------------------------------- replay

    /** Pluggable engine construction so the same driver can run other engine implementations. */
    fun interface EngineFactory {
        fun create(cameras: List<CameraPoint>, host: CameraEngineHost, clock: () -> Long): ReplayEngine
    }

    interface ReplayEngine {
        fun resetTrackingAfterLocationGap()
        fun evaluateAndDispatch(fix: CameraFix)
        fun bridgeAndDispatch(locationAgeMs: Long, speedKmh: Float)
    }

    val realEngine = EngineFactory { cameras, host, clock ->
        val engine = CameraEngine(cameras, AospGeodesy, host, clock)
        object : ReplayEngine {
            override fun resetTrackingAfterLocationGap() = engine.resetTrackingAfterLocationGap()
            override fun evaluateAndDispatch(fix: CameraFix) {
                // Same sequence as LocationService.evaluateAllCameras()
                val result = engine.evaluateAllCameras(fix)
                engine.dispatchCameraAlerts(result.alertRequests)
                engine.cleanupOldCameraStates(fix.nowElapsedMs)
            }
            override fun bridgeAndDispatch(locationAgeMs: Long, speedKmh: Float) {
                // Same sequence as LocationService.bridgeConfirmedCameraAlerts()
                val requests = engine.bridgeConfirmedCameraAlerts(locationAgeMs, speedKmh)
                if (requests.isNotEmpty()) engine.dispatchCameraAlerts(requests)
            }
        }
    }

    open class RecordingHost(private val clock: () -> Long) : CameraEngineHost {
        val events = ArrayList<Event>()
        val outputs = ArrayList<Output>()
        override val negativeRoutePolicy = "replay_no_negative_routes"

        override fun cameraEvent(event: String, geometry: CameraGeometry, state: CameraTrackState, extra: String) {
            events += Event(clock(), event, geometry.cluster.key, state.phase, state.warned,
                geometry.directDistanceM, geometry.vehicleForwardM, extra)
        }

        // Pure core replay: explicit negative routes (v0.15 veto) are validated separately
        // by tools/negative_route_warning_regression.py against the road-geometry DB.
        var negativeRoutes: (List<String>) -> NegativeRouteEvidence? = { null }
        val negativeRouteQueries = ArrayList<List<String>>()

        override fun explicitNegativeRoute(
            cameraIds: List<String>, cameraType: String, lat: Double, lon: Double, vehicleBearingDeg: Float?
        ): NegativeRouteEvidence? {
            negativeRouteQueries += cameraIds
            return negativeRoutes(cameraIds)
        }

        override fun cameraAlertOutput(request: AlertRequest, suppressedCount: Int, firstAlert: Boolean) {
            outputs += Output(clock(), request.geometry.cluster.key, request.level, firstAlert, request.bridge)
            events += Event(clock(), "ALERT_OUTPUT", request.geometry.cluster.key, request.state.phase,
                request.state.warned, request.geometry.directDistanceM, request.geometry.vehicleForwardM,
                "level=${request.level};first_alert=$firstAlert;bridge=${request.bridge};suppressed=$suppressedCount")
        }
    }

    fun replay(
        tripName: String,
        cameras: List<CameraPoint>,
        factory: EngineFactory = realEngine,
        emulateHealthTicker: Boolean = false,
        negativeRoutes: (List<String>) -> NegativeRouteEvidence? = { null }
    ): Result {
        val rows = loadLocationRows(fixture(tripName))
        var now = 0L
        val clock = { now }
        val host = RecordingHost(clock)
        host.negativeRoutes = negativeRoutes
        val engine = factory.create(cameras, host, clock)

        var lastFixTime = 0L
        var lastSpeed = 0f
        var fixes = 0

        for (row in rows) {
            if (emulateHealthTicker && lastFixTime > 0L) {
                var t = lastFixTime + HEALTH_TICK_MS
                while (t < row.wallTimeMs) {
                    val age = t - lastFixTime
                    if (age in GPS_CAMERA_BRIDGE_START_MS..GPS_CAMERA_BRIDGE_MAX_MS) {
                        now = t
                        engine.bridgeAndDispatch(age, lastSpeed)
                    }
                    t += HEALTH_TICK_MS
                }
            }

            now = row.wallTimeMs
            fixes++
            if (row.locationGapMs >= LOCATION_RECOVERY_RESET_MS) engine.resetTrackingAfterLocationGap()
            lastFixTime = row.wallTimeMs
            lastSpeed = row.speedKmh

            val bearing = row.bearingDeg
            if (!row.bearingValid || bearing == null) continue

            engine.evaluateAndDispatch(
                CameraFix(
                    nowElapsedMs = now,
                    lat = row.lat,
                    lon = row.lon,
                    bearingDeg = bearing,
                    accuracyM = row.accuracyM,
                    speedKmh = row.speedKmh,
                    recoveredLocationGapMs = row.locationGapMs
                )
            )
        }
        return Result(tripName, fixes, host.events, host.outputs)
    }
}
