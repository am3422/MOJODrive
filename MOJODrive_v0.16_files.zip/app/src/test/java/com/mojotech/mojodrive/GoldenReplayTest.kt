package com.mojotech.mojodrive

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Golden field-trip regression for the REAL Kotlin camera engine.
 *
 * tools/golden_v012_replay.json lists, for each recorded trip, the exact sequence of first
 * camera warnings of the field-validated engine. Every trip is replayed through CameraEngine
 * (the class the APK runs) and must reproduce that sequence exactly: same cameras, same order,
 * nothing missing, nothing extra.
 */
class GoldenReplayTest {

    private val golden = TripReplay.loadGolden()
    private val snapshot = TripReplay.loadCameraSnapshot()

    @Test
    fun cameraSnapshotIsTheGoldenDatabase() {
        assertEquals(
            "camera_db_snapshot.tsv was exported from a different camera DB than the golden trips use",
            golden.first,
            snapshot.first
        )
        assertTrue("camera snapshot is empty", snapshot.second.isNotEmpty())
    }

    @Test
    fun everyGoldenTripReproducesItsFirstWarningsExactly() {
        val failures = ArrayList<String>()
        var total = 0
        for ((trip, expected) in golden.second) {
            val actual = TripReplay.replay(trip, snapshot.second).firstWarnings
            total += expected.size
            if (actual != expected) {
                failures += "$trip\n  expected=$expected\n  actual  =$actual"
            } else {
                println("KOTLIN REPLAY PASS $trip: ${actual.size} first warnings, exact sequence match")
            }
        }
        assertTrue("Kotlin engine replay differs from golden field trips:\n" + failures.joinToString("\n"), failures.isEmpty())
        println("KOTLIN REPLAY: PASS — $total/$total golden first-warning encounters reproduced by CameraEngine")
    }

    @Test
    fun everyFirstWarningProducesAnAudibleFirstAlert() {
        // v0.10 rule: every warned physical camera cluster gets its first beep/vibration;
        // arbitration may delay it briefly but must never swallow it.
        for (trip in golden.second.keys) {
            val result = TripReplay.replay(trip, snapshot.second)
            val pending = HashMap<String, Long>()
            for (e in result.events) {
                if (e.type == "CAMERA_WARNING") pending[e.clusterKey] = e.timeMs
                if (e.type == "ALERT_OUTPUT" && e.extra.contains("first_alert=true")) {
                    val warnedAt = pending.remove(e.clusterKey)
                    assertTrue("$trip: first alert for ${e.clusterKey} without a warning", warnedAt != null)
                    assertTrue(
                        "$trip: first alert for ${e.clusterKey} delayed ${e.timeMs - warnedAt!!} ms",
                        e.timeMs - warnedAt <= 5_000L
                    )
                }
            }
            assertTrue("$trip: warned cameras never got a first alert: ${pending.keys}", pending.isEmpty())
        }
    }

    @Test
    fun noAlertIsOutputForACameraAfterItWasPassed() {
        // v0.7 rule: once a camera is behind the car, it must stay silent (with the GPS-gap
        // bridge emulated too, so dead-reckoning can never beep for a camera already passed).
        for (trip in golden.second.keys) {
            val result = TripReplay.replay(trip, snapshot.second, emulateHealthTicker = true)
            val passed = HashSet<String>()
            for (e in result.events) {
                when (e.type) {
                    "CAMERA_PASSED", "CAMERA_ABANDONED" -> passed += e.clusterKey
                    "CAMERA_MATCH_CONFIRMED" -> passed -= e.clusterKey // a new encounter
                    "ALERT_OUTPUT" -> assertTrue(
                        "$trip: alert for ${e.clusterKey} at ${e.timeMs} after it was passed",
                        e.clusterKey !in passed
                    )
                }
            }
        }
    }
}
