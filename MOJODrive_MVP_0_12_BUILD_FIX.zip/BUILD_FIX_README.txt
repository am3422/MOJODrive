MOJO Drive MVP 0.12 build fix

Root cause of GitHub Actions run #21 failure:
play-services-location:21.3.0 depends on AndroidX, while the project still had android.useAndroidX=false.

Fix applied:
android.useAndroidX=true

No Kotlin/Camera/GPS/Speed logic is changed by this patch.
