#!/usr/bin/env bash
set -euo pipefail

LEGACY="${1:-extract_iran_cameras.py}"
OUT="${2:-iran_mojodrive_dataset}"

python3 -m pip install -r requirements.txt
python3 iran_mojodrive_extractor.py --self-test
python3 iran_mojodrive_extractor.py \
  --legacy-config "$LEGACY" \
  --out "$OUT" \
  --levels ADM1 ADM2 ADM3 ADM4 \
  --workers 4 \
  --retries 8
