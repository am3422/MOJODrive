# MOJODrive Iran Data Extractor

این ابزار برای مشکل مهمی که در پروژه دیدیم طراحی شده: **نباید دیتابیس ایران، فارس و شیراز با crawlهای مستقل ساخته شوند** چون در زمان/خطاهای مختلف ممکن است یک دوربین در یکی باشد و در دیگری نباشد.

## معماری جدید

1. کل ایران در یک **snapshot مشترک** crawl می‌شود.
2. همان raw tile cache برای همه خروجی‌ها استفاده می‌شود.
3. از master واحد، فایل‌های ایران، استان‌ها و تقسیمات اداری کوچک‌تر ساخته می‌شوند.
4. در نتیجه یک دوربین که در یک استان ثبت شده، به‌صورت ساختاری از همان master ایران آمده است؛ نه از crawl دیگری.

## خروجی‌ها

برای کل ایران و هر region دارای دوربین:

- `cameras_mojodrive.sqlite` — schema سازگار با `CameraDatabase.kt`
- `cameras_full.csv` — شامل source id/type و metadata کامل road/direction
- `roads_near_cameras.sqlite` — road segmentهای اطراف دوربین‌ها + candidate mapping
- `region.json`

همچنین:

- `master/iran_master.sqlite`
- `reports/quality_summary.json`
- `reports/needs_direction_review.csv`
- `reports/completeness.json`
- `regions_index.csv`

## Direction metadata

برای هر camera نزدیک‌ترین road segment پیدا می‌شود و این فیلدها ساخته می‌شوند:

- `road_bearing`
- `road_axis_bearing`
- `oneway`
- `direction_mode`
- `direction_confidence`
- `direction_source`
- `road_layer`
- `road_name`
- `road_highway`
- `road_distance_m`

اگر provider فیلد one-way را صریحاً بدهد، جهت با confidence بالا/متوسط ذخیره می‌شود.

به‌صورت پیش‌فرض یک inference محافظه‌کارانه نیز برای **دو carriageway موازی** فعال است: فقط وقتی دو road line مجزا، نزدیک، موازی و raw direction آنها تقریباً 180 درجه مخالف باشد. منبع این inference در `direction_source=parallel_carriageway_geometry` مشخص می‌شود و در report قابل audit است. برای خاموش‌کردنش:

```bash
--no-parallel-inference
```

## نکته مهم درباره «شهر»

geoBoundaries برای ایران ADM0 تا ADM4 دارد، اما ADM2/ADM3/ADM4 الزاماً معادل «مرز شهرداری شهر» نیستند؛ تقسیمات اداری‌اند. اسکریپت همه ADM1..ADM4 را جدا می‌کند. اگر GeoJSON دقیق شهرها را داری، بده:

```bash
--custom-cities cities.geojson
```

و خروجی دقیق آن‌ها زیر `CITIES_CUSTOM` ساخته می‌شود.

## Credential / endpoint

این package عمداً هیچ key/secret قبلی را تکرار نمی‌کند. راحت‌ترین روش این است که extractor قدیمی و working خودت را کنار این فایل بگذاری و بدهی:

```bash
python3 iran_mojodrive_extractor.py \
  --legacy-config ../extract_iran_cameras.py \
  --out iran_mojodrive_dataset \
  --levels ADM1 ADM2 ADM3 ADM4
```

اسکریپت فقط assignmentهای literal `KEY`, `URL`, `BASEMAP_URL`, `HEADERS` را با AST می‌خواند و فایل قدیمی را execute نمی‌کند.

یا یک `provider_config.json` محلی بساز؛ template داخل package هست.

## Codespaces

```bash
unzip MOJODrive_Iran_Data_Extractor.zip
cd MOJODrive_Iran_Data_Extractor
pip install -r requirements.txt
python iran_mojodrive_extractor.py --self-test
python iran_mojodrive_extractor.py \
  --legacy-config ../extract_iran_cameras.py \
  --out ../iran_mojodrive_dataset \
  --levels ADM1 ADM2 ADM3 ADM4 \
  --workers 4 \
  --retries 8
```

یا:

```bash
./run_all.sh ../extract_iran_cameras.py ../iran_mojodrive_dataset
```

## Resume و کامل بودن

Raw tileها در `cache/` می‌مانند. اگر اینترنت/سرور قطع شد، اجرای بعدی فقط tileهای fail شده را retry می‌کند.

در پایان `reports/completeness.json` را نگاه کن. تا وقتی `complete=true` نشده، dataset را Production-ready فرض نکن.

## چرا camera_id جدید `IR_...` است؟

در تست‌های قبلی دیدیم provider برای یک مختصات یکسان در crawlهای مختلف ID متفاوت می‌دهد. بنابراین runtime ID با `type + coordinate` به‌صورت deterministic ساخته می‌شود و source ID اصلی جدا در master/CSV نگه داشته می‌شود.

## پیشنهاد برای MOJODrive

برای نسخه Product، cameraهایی که `direction_confidence=unknown/low/both` هستند را بدون تست میدانی به‌عنوان directed camera قبول نکن. فایل `needs_direction_review.csv` دقیقاً برای همین است.
