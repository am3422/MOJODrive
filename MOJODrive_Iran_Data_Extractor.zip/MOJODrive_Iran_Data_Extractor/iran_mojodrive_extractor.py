#!/usr/bin/env python3
"""
MOJODrive Iran camera + road-direction dataset builder.

Design goals:
- Crawl ONE shared national snapshot, then derive every province/admin-region file from it.
  This prevents the old "Shiraz exists but Fars/Iran is missing it" problem caused by
  separate crawls at different times / with different failed tiles.
- Keep provider credentials OUT of this file. The script can safely read KEY/URL/
  BASEMAP_URL/HEADERS constants from one of the user's existing working extractor files.
- Extract all camera-like POIs, not only one hard-coded speed-camera type.
- Enrich every camera with nearest-road axis, one-way direction when available, layer,
  road class/name, speed metadata, and nearby alternate carriageways.
- Export a MOJODrive-compatible runtime SQLite for Iran and each administrative region.
- Cache raw vector tiles and support resume/retry/completeness verification.

This tool does not alter the MOJODrive alert algorithm. It only builds data.
"""
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import math
import os
import re
import sqlite3
import sys
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import requests
from shapely.geometry import Point, box, shape, mapping
from shapely.ops import unary_union
from shapely.prepared import prep

APP_SCHEMA_COLUMNS = [
    "camera_id", "camera_type", "latitude", "longitude", "speed_limit",
    "road_name", "road_highway", "road_distance_m", "speed_source",
    "speed_confidence", "road_bearing", "oneway", "direction_mode",
    "direction_confidence", "road_layer",
]

DEFAULT_Z = 14
DEFAULT_WORKERS = 4
DEFAULT_TIMEOUT = 20
DEFAULT_RETRIES = 6
DEFAULT_REQUEST_GAP = 0.03
DEFAULT_ROAD_MATCH_MAX_M = 60.0
DEFAULT_ROAD_CANDIDATE_RADIUS_M = 140.0
DEFAULT_EDGE_NEIGHBOR_TRIGGER_M = 120.0
DEFAULT_LEVELS = ("ADM1", "ADM2", "ADM3", "ADM4")

GB_API = "https://www.geoboundaries.org/api/current/gbOpen/IRN/{level}/"
EXCLUDED_ROAD_CLASSES = {"footway", "path", "steps", "pedestrian", "cycleway"}
DIRECTIONAL_CLASSES = {"motorway", "motorway_link", "trunk", "trunk_link", "primary", "primary_link"}

_thread_local = threading.local()
_cache_locks: Dict[str, threading.Lock] = {}
_cache_locks_guard = threading.Lock()


@dataclass(frozen=True)
class ProviderConfig:
    xor_key: bytes
    traffic_url: str
    basemap_url: str
    headers: Dict[str, str]


@dataclass
class RoadMetric:
    road_key: str
    layer: str
    feature_id: str
    tile_z: int
    tile_x: int
    tile_y: int
    distance_m: float
    axis_bearing_deg: float
    directed_bearing_deg: Optional[float]
    oneway: int
    direction_mode: str
    direction_confidence: str
    direction_source: str
    speed_limit: Optional[int]
    road_name: str
    road_highway: str
    road_properties_json: str
    geometry_json: str


def die(msg: str, code: int = 2) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(code)


def normalize_text(value: Any) -> str:
    s = unicodedata.normalize("NFKD", str(value or ""))
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return " ".join(s.casefold().replace("-", " ").replace("_", " ").split())


def slugify(value: str, fallback: str = "region") -> str:
    s = unicodedata.normalize("NFKD", value or "")
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"[^0-9A-Za-z\u0600-\u06FF]+", "_", s).strip("_")
    return s[:100] or fallback


def sha1_text(s: str, n: int = 20) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:n]


def stable_camera_uid(camera_type: str, lat: float, lon: float) -> str:
    # Coordinates are the only cross-file identity that proved more stable than provider IDs.
    return "IR_" + sha1_text(f"{camera_type}|{lat:.7f}|{lon:.7f}", 16)


def literal_assignments_from_py(path: Path) -> Dict[str, Any]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    out: Dict[str, Any] = {}
    wanted = {"KEY", "URL", "BASEMAP_URL", "HEADERS"}
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        value_node = node.value
        for target in targets:
            if isinstance(target, ast.Name) and target.id in wanted:
                try:
                    out[target.id] = ast.literal_eval(value_node)
                except Exception:
                    pass
    return out


def load_provider_config(legacy_config: Optional[Path], json_config: Optional[Path]) -> ProviderConfig:
    if legacy_config:
        vals = literal_assignments_from_py(legacy_config)
        missing = [k for k in ("KEY", "URL", "BASEMAP_URL", "HEADERS") if k not in vals]
        if missing:
            die(f"legacy config is missing literal assignments: {', '.join(missing)}")
        key = vals["KEY"]
        if not isinstance(key, (bytes, bytearray)):
            die("legacy KEY must be a bytes literal")
        return ProviderConfig(bytes(key), str(vals["URL"]), str(vals["BASEMAP_URL"]), dict(vals["HEADERS"]))

    if json_config:
        cfg = json.loads(json_config.read_text(encoding="utf-8"))
        key_hex = cfg.get("xor_key_hex", "")
        if not key_hex:
            die("provider JSON must contain xor_key_hex")
        return ProviderConfig(
            bytes.fromhex(key_hex),
            cfg["traffic_url"],
            cfg["basemap_url"],
            dict(cfg.get("headers", {})),
        )

    # Environment-only fallback. Intentionally no provider secrets are embedded here.
    key_hex = os.environ.get("MOJODRIVE_XOR_KEY_HEX", "")
    traffic = os.environ.get("MOJODRIVE_TRAFFIC_URL", "")
    basemap = os.environ.get("MOJODRIVE_BASEMAP_URL", "")
    headers_json = os.environ.get("MOJODRIVE_PROVIDER_HEADERS_JSON", "{}")
    if not (key_hex and traffic and basemap):
        die("provide --legacy-config, --provider-config, or MOJODRIVE_* environment variables")
    return ProviderConfig(bytes.fromhex(key_hex), traffic, basemap, json.loads(headers_json))


def session(headers: Dict[str, str]) -> requests.Session:
    key = json.dumps(headers, sort_keys=True, ensure_ascii=False)
    sessions = getattr(_thread_local, "sessions", None)
    if sessions is None:
        sessions = {}
        _thread_local.sessions = sessions
    if key not in sessions:
        s = requests.Session()
        s.headers.update(headers)
        sessions[key] = s
    return sessions[key]


def query_xy(z: int, x: int, y: int) -> Tuple[int, int]:
    qx = ((x << z) + (y << (z - 1))) * z
    qy = ((y << (z + 1)) - (x << z)) * (z - 1)
    return qx, qy


def decode_tile(data: bytes, xor_key: bytes) -> Dict[str, Any]:
    try:
        import mapbox_vector_tile
    except ImportError:
        die("mapbox-vector-tile is not installed. Run: pip install -r requirements.txt")
    raw = bytes(b ^ xor_key[i % len(xor_key)] for i, b in enumerate(data))
    if raw[:3] != b"\x1f\x8b\x08":
        raise ValueError(f"unexpected decoded header: {raw[:12].hex()}")
    import zlib
    inflated = zlib.decompress(raw, 31)
    return mapbox_vector_tile.decode(inflated, default_options={"y_coord_down": True})


def latlon_to_tile_fraction(lat: float, lon: float, z: int) -> Tuple[float, float]:
    n = 1 << z
    x = (lon + 180.0) / 360.0 * n
    y = (1.0 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2.0 * n
    return x, y


def tile_y_to_lat(y: float, z: int) -> float:
    n = 1 << z
    return math.degrees(math.atan(math.sinh(math.pi * (1.0 - 2.0 * y / n))))


def tile_bounds(z: int, x: int, y: int) -> Tuple[float, float, float, float]:
    n = 1 << z
    lon1 = x / n * 360.0 - 180.0
    lon2 = (x + 1) / n * 360.0 - 180.0
    lat1 = tile_y_to_lat(y + 1, z)
    lat2 = tile_y_to_lat(y, z)
    return lon1, lat1, lon2, lat2


def point_to_latlon(z: int, tx: int, ty: int, px: float, py: float, extent: float) -> Tuple[float, float]:
    n = 1 << z
    world_x = tx + px / extent
    world_y = ty + py / extent
    lon = world_x / n * 360.0 - 180.0
    merc = math.pi * (1.0 - 2.0 * world_y / n)
    lat = math.degrees(math.atan(math.sinh(merc)))
    return lat, lon


def local_xy_m(lat: float, lon: float, lat0: float, lon0: float) -> Tuple[float, float]:
    east = (lon - lon0) * 111320.0 * math.cos(math.radians(lat0))
    north = (lat - lat0) * 110540.0
    return east, north


def bearing_from_xy(dx: float, dy: float) -> float:
    return (math.degrees(math.atan2(dx, dy)) + 360.0) % 360.0


def angle_diff(a: float, b: float) -> float:
    return abs((a - b + 180.0) % 360.0 - 180.0)


def closest_on_segment(px: float, py: float, ax: float, ay: float, bx: float, by: float) -> Tuple[float, float, float]:
    vx, vy = bx - ax, by - ay
    denom = vx * vx + vy * vy
    if denom <= 1e-12:
        return math.hypot(px - ax, py - ay), 0.0, 0.0
    t = ((px - ax) * vx + (py - ay) * vy) / denom
    t = max(0.0, min(1.0, t))
    qx, qy = ax + t * vx, ay + t * vy
    return math.hypot(px - qx, py - qy), vx, vy


def geometry_lines(geom: Dict[str, Any]) -> Iterable[List[Sequence[float]]]:
    gt = geom.get("type")
    coords = geom.get("coordinates") or []
    if gt == "LineString":
        yield coords
    elif gt == "MultiLineString":
        for line in coords:
            yield line


def line_metric_wgs84(geom: Dict[str, Any], z: int, tx: int, ty: int, extent: int,
                       camera_lat: float, camera_lon: float) -> Optional[Tuple[float, float, str]]:
    best: Optional[Tuple[float, float]] = None
    out_lines: List[List[List[float]]] = []
    for line in geometry_lines(geom):
        if len(line) < 2:
            continue
        wgs: List[List[float]] = []
        xy: List[Tuple[float, float]] = []
        for p in line:
            lat, lon = point_to_latlon(z, tx, ty, float(p[0]), float(p[1]), extent)
            wgs.append([lon, lat])
            xy.append(local_xy_m(lat, lon, camera_lat, camera_lon))
        out_lines.append(wgs)
        for i in range(len(xy) - 1):
            ax, ay = xy[i]
            bx, by = xy[i + 1]
            d, vx, vy = closest_on_segment(0.0, 0.0, ax, ay, bx, by)
            if abs(vx) + abs(vy) < 1e-9:
                continue
            b = bearing_from_xy(vx, vy)
            if best is None or d < best[0]:
                best = (d, b)
    if best is None:
        return None
    gj = {"type": "MultiLineString" if len(out_lines) > 1 else "LineString",
          "coordinates": out_lines if len(out_lines) > 1 else out_lines[0]}
    return best[0], best[1], json.dumps(gj, ensure_ascii=False, separators=(",", ":"))


def parse_boolish(v: Any) -> Optional[bool]:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        if v == 0: return False
        if v == 1: return True
    s = normalize_text(v)
    if s in {"yes", "true", "1", "oneway", "forward"}: return True
    if s in {"no", "false", "0", "both", "two way", "twoway"}: return False
    return None


def parse_oneway(props: Dict[str, Any]) -> Tuple[int, str]:
    # Returns +1 along geometry, -1 against geometry, 0 no/unknown.
    for key in ("oneway", "one_way", "is_oneway", "oneWay"):
        if key not in props:
            continue
        v = props.get(key)
        if isinstance(v, (int, float)) and int(v) == -1:
            return -1, f"property:{key}"
        raw_s = str(v).strip().casefold()
        s = normalize_text(v)
        if raw_s == "-1" or s in {"reverse", "backward"}:
            return -1, f"property:{key}"
        b = parse_boolish(v)
        if b is True:
            return 1, f"property:{key}"
        if b is False:
            return 0, f"property:{key}"
    # Some vector schemas use a generic direction field.
    for key in ("direction", "dir", "travel_dir"):
        if key not in props:
            continue
        raw_s = str(props.get(key)).strip().casefold()
        s = normalize_text(props.get(key))
        if s in {"forward", "1", "yes"}: return 1, f"property:{key}"
        if raw_s == "-1" or s in {"reverse", "backward"}: return -1, f"property:{key}"
        if s in {"both", "0", "two way", "twoway"}: return 0, f"property:{key}"
    return 0, "not_exposed"


def parse_speed_limit(props: Dict[str, Any]) -> Tuple[Optional[int], str]:
    # Preserve compatibility with the user's previous extractor: routable was yielding
    # values such as 50/80/110 in this vector schema. Prefer explicit speed keys if present.
    for key in ("maxspeed", "speed_limit", "speed", "routable"):
        if key not in props:
            continue
        v = props.get(key)
        m = re.search(r"\d{2,3}", str(v))
        if not m:
            continue
        n = int(m.group())
        if 20 <= n <= 150:
            return n, f"basemap.{key}"
    return None, ""


def camera_kind(source_type: str) -> str:
    s = normalize_text(source_type)
    if "speed" in s:
        return "speed"
    if "red" in s or "light" in s or "signal" in s:
        return "red_light"
    return "camera"


def is_camera_poi(source_type: Any) -> bool:
    s = normalize_text(source_type)
    return bool(s and "camera" in s)


def cache_lock(path: Path) -> threading.Lock:
    k = str(path)
    with _cache_locks_guard:
        return _cache_locks.setdefault(k, threading.Lock())


def fetch_cached(provider: ProviderConfig, kind: str, z: int, x: int, y: int, cache_root: Path,
                 timeout: int, retries: int, request_gap: float) -> bytes:
    p = cache_root / kind / str(z) / str(x) / f"{y}.bin"
    if p.exists() and p.stat().st_size > 0:
        return p.read_bytes()
    p.parent.mkdir(parents=True, exist_ok=True)
    lock = cache_lock(p)
    with lock:
        if p.exists() and p.stat().st_size > 0:
            return p.read_bytes()
        qx, qy = query_xy(z, x, y)
        template = provider.traffic_url if kind == "traffic" else provider.basemap_url
        url = template.format(z=z, x=x, y=y)
        last_error: Optional[Exception] = None
        for attempt in range(retries):
            try:
                r = session(provider.headers).get(url, params={"x": str(qx), "y": str(qy)}, timeout=timeout)
                if r.status_code == 429:
                    time.sleep(min(60.0, 2.0 ** (attempt + 1)))
                    continue
                r.raise_for_status()
                tmp = p.with_suffix(".tmp")
                tmp.write_bytes(r.content)
                tmp.replace(p)
                if request_gap:
                    time.sleep(request_gap)
                return r.content
            except Exception as e:
                last_error = e
                time.sleep(min(30.0, 0.5 * (2 ** attempt)))
        raise RuntimeError(f"{kind} tile {z}/{x}/{y} failed after {retries} tries: {last_error}")


def fetch_geojson_cached(url: str, path: Path, timeout: int = 60) -> Dict[str, Any]:
    if path.exists() and path.stat().st_size > 0:
        return json.loads(path.read_text(encoding="utf-8"))
    path.parent.mkdir(parents=True, exist_ok=True)
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    obj = r.json()
    path.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")
    return obj


def load_boundary_level(level: str, cache_root: Path) -> Dict[str, Any]:
    meta_path = cache_root / "boundaries" / f"{level}_meta.json"
    meta = fetch_geojson_cached(GB_API.format(level=level), meta_path, timeout=30)
    gj_url = meta["gjDownloadURL"]
    return fetch_geojson_cached(gj_url, cache_root / "boundaries" / f"{level}.geojson", timeout=120)


def init_master_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript("""
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS tile_status(
        kind TEXT NOT NULL, z INTEGER NOT NULL, x INTEGER NOT NULL, y INTEGER NOT NULL,
        status TEXT NOT NULL, error TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(kind,z,x,y)
    );
    CREATE TABLE IF NOT EXISTS cameras(
        camera_uid TEXT PRIMARY KEY,
        source_camera_id TEXT,
        camera_type TEXT NOT NULL,
        source_type TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        source_highway INTEGER,
        zoom_level INTEGER,
        tile_z INTEGER, tile_x INTEGER, tile_y INTEGER,
        properties_json TEXT,
        speed_limit INTEGER,
        road_name TEXT,
        road_highway TEXT,
        road_distance_m REAL,
        speed_source TEXT,
        speed_confidence TEXT,
        road_bearing REAL,
        road_axis_bearing REAL,
        oneway INTEGER NOT NULL DEFAULT 0,
        direction_mode TEXT NOT NULL DEFAULT 'unknown',
        direction_confidence TEXT NOT NULL DEFAULT 'unknown',
        direction_source TEXT NOT NULL DEFAULT '',
        road_layer TEXT NOT NULL DEFAULT '',
        matched_road_key TEXT,
        road_properties_json TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_cameras_ll ON cameras(latitude,longitude);
    CREATE INDEX IF NOT EXISTS idx_cameras_source_id ON cameras(source_camera_id);
    CREATE TABLE IF NOT EXISTS roads(
        road_key TEXT PRIMARY KEY,
        layer TEXT NOT NULL,
        feature_id TEXT,
        road_name TEXT,
        road_highway TEXT,
        speed_limit INTEGER,
        axis_bearing REAL,
        directed_bearing REAL,
        oneway INTEGER NOT NULL DEFAULT 0,
        direction_mode TEXT,
        direction_confidence TEXT,
        direction_source TEXT,
        tile_z INTEGER, tile_x INTEGER, tile_y INTEGER,
        properties_json TEXT,
        geometry_json TEXT
    );
    CREATE TABLE IF NOT EXISTS camera_road_candidates(
        camera_uid TEXT NOT NULL,
        road_key TEXT NOT NULL,
        distance_m REAL NOT NULL,
        rank_no INTEGER NOT NULL,
        PRIMARY KEY(camera_uid,road_key)
    );
    CREATE TABLE IF NOT EXISTS regions(
        region_id TEXT PRIMARY KEY,
        adm_level TEXT NOT NULL,
        region_name TEXT NOT NULL,
        source_shape_id TEXT,
        geometry_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS camera_regions(
        camera_uid TEXT NOT NULL,
        region_id TEXT NOT NULL,
        assignment_method TEXT NOT NULL,
        PRIMARY KEY(camera_uid,region_id)
    );
    """)
    con.commit()
    return con


def put_meta(con: sqlite3.Connection, key: str, value: Any) -> None:
    con.execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", (key, str(value)))


def build_tile_list(region_geom: Any, z: int) -> List[Tuple[int, int]]:
    min_lon, min_lat, max_lon, max_lat = region_geom.bounds
    fx1, fy1 = latlon_to_tile_fraction(max_lat, min_lon, z)
    fx2, fy2 = latlon_to_tile_fraction(min_lat, max_lon, z)
    x_min = max(0, int(math.floor(min(fx1, fx2))))
    x_max = min((1 << z) - 1, int(math.floor(max(fx1, fx2))))
    y_min = max(0, int(math.floor(min(fy1, fy2))))
    y_max = min((1 << z) - 1, int(math.floor(max(fy1, fy2))))
    prepared = prep(region_geom)
    out: List[Tuple[int, int]] = []
    for x in range(x_min, x_max + 1):
        for y in range(y_min, y_max + 1):
            lon1, lat1, lon2, lat2 = tile_bounds(z, x, y)
            if prepared.intersects(box(lon1, lat1, lon2, lat2)):
                out.append((x, y))
    return out


def download_traffic_snapshot(con: sqlite3.Connection, provider: ProviderConfig, tiles: List[Tuple[int,int]],
                              z: int, cache_root: Path, workers: int, timeout: int, retries: int,
                              request_gap: float) -> None:
    existing = {(r[0], r[1]): r[2] for r in con.execute(
        "SELECT x,y,status FROM tile_status WHERE kind='traffic' AND z=?", (z,))}
    pending = [(x,y) for x,y in tiles if existing.get((x,y)) != "ok"]
    print(f"Traffic tiles: total={len(tiles)} cached_db_ok={len(tiles)-len(pending)} pending={len(pending)}")
    if not pending:
        return

    def work(t: Tuple[int,int]) -> Tuple[int,int,Optional[str]]:
        x,y=t
        try:
            fetch_cached(provider, "traffic", z, x, y, cache_root, timeout, retries, request_gap)
            return x,y,None
        except Exception as e:
            return x,y,f"{type(e).__name__}: {e}"

    done=0; failures=0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futs={pool.submit(work,t):t for t in pending}
        for f in as_completed(futs):
            x,y,err=f.result(); done+=1
            if err:
                failures+=1
                con.execute("INSERT OR REPLACE INTO tile_status(kind,z,x,y,status,error,updated_at) VALUES('traffic',?,?,?,'failed',?,CURRENT_TIMESTAMP)", (z,x,y,err))
            else:
                con.execute("INSERT OR REPLACE INTO tile_status(kind,z,x,y,status,error,updated_at) VALUES('traffic',?,?,?,'ok',NULL,CURRENT_TIMESTAMP)", (z,x,y))
            if done % 100 == 0 or done == len(pending):
                con.commit()
                print(f"traffic download {done}/{len(pending)} failures={failures}")
    con.commit()
    if failures:
        print(f"WARNING: {failures} traffic tiles failed. Re-run; failed tiles are never marked complete.")


def extract_cameras_from_cached_traffic(con: sqlite3.Connection, provider: ProviderConfig, tiles: List[Tuple[int,int]],
                                        country_geom: Any, z: int, cache_root: Path) -> None:
    country_prep=prep(country_geom)
    inserted=0
    for i,(x,y) in enumerate(tiles,1):
        status=con.execute("SELECT status FROM tile_status WHERE kind='traffic' AND z=? AND x=? AND y=?",(z,x,y)).fetchone()
        if not status or status[0] != "ok":
            continue
        p=cache_root/"traffic"/str(z)/str(x)/f"{y}.bin"
        if not p.exists():
            continue
        tile=decode_tile(p.read_bytes(), provider.xor_key)
        layer=tile.get("poi")
        if not layer:
            continue
        extent=int(layer.get("extent",4096))
        for f in layer.get("features",[]):
            props=f.get("properties",{}) or {}
            source_type=str(props.get("type") or "")
            if not is_camera_poi(source_type):
                continue
            geom=f.get("geometry",{}) or {}
            if geom.get("type") != "Point":
                continue
            px,py=geom["coordinates"]
            lat,lon=point_to_latlon(z,x,y,float(px),float(py),extent)
            if not country_prep.covers(Point(lon,lat)):
                continue
            ctype=camera_kind(source_type)
            uid=stable_camera_uid(ctype,lat,lon)
            sid=props.get("id")
            con.execute("""
              INSERT OR REPLACE INTO cameras(
                camera_uid,source_camera_id,camera_type,source_type,latitude,longitude,
                source_highway,zoom_level,tile_z,tile_x,tile_y,properties_json
              ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """,(uid,"" if sid is None else str(sid),ctype,source_type,lat,lon,props.get("highway"),props.get("zoom_level"),z,x,y,
                 json.dumps(props,ensure_ascii=False,separators=(",",":"))))
            inserted+=1
        if i%500==0:
            con.commit(); print(f"camera decode {i}/{len(tiles)} unique={con.execute('SELECT COUNT(*) FROM cameras').fetchone()[0]}")
    con.commit()
    print(f"Camera snapshot unique={con.execute('SELECT COUNT(*) FROM cameras').fetchone()[0]} (raw inserts={inserted})")


def candidate_tiles_for_camera(lat: float, lon: float, z: int, edge_trigger_m: float) -> List[Tuple[int,int]]:
    fx,fy=latlon_to_tile_fraction(lat,lon,z)
    x,y=int(math.floor(fx)),int(math.floor(fy))
    fracx,fracy=fx-x,fy-y
    meters_per_tile=40075016.686*math.cos(math.radians(lat))/(1<<z)
    edge=min(fracx,1-fracx,fracy,1-fracy)*meters_per_tile
    out=[(x,y)]
    if edge <= edge_trigger_m:
        for dx in (-1,0,1):
            for dy in (-1,0,1):
                if dx or dy:
                    out.append((x+dx,y+dy))
    return out


def basemap_road_metrics(provider: ProviderConfig, z: int, tx: int, ty: int, camera_lat: float, camera_lon: float,
                         cache_root: Path, timeout: int, retries: int, request_gap: float,
                         candidate_radius_m: float) -> List[RoadMetric]:
    data=fetch_cached(provider,"basemap",z,tx,ty,cache_root,timeout,retries,request_gap)
    tile=decode_tile(data,provider.xor_key)
    out: List[RoadMetric]=[]
    for layer_name in ("street","bridge","tunnel"):
        layer=tile.get(layer_name)
        if not layer: continue
        extent=int(layer.get("extent",4096))
        for idx,f in enumerate(layer.get("features",[])):
            props=f.get("properties",{}) or {}
            hwy=str(props.get("highway") or "")
            if normalize_text(hwy) in EXCLUDED_ROAD_CLASSES:
                continue
            metric=line_metric_wgs84(f.get("geometry",{}) or {},z,tx,ty,extent,camera_lat,camera_lon)
            if metric is None: continue
            dist,axis_bearing,geometry_json=metric
            if dist > candidate_radius_m: continue
            sign,dir_source=parse_oneway(props)
            speed,speed_source=parse_speed_limit(props)
            road_name=str(props.get("name") or props.get("name_fa") or props.get("name_en") or "")
            fid=str(f.get("id") if f.get("id") is not None else "")
            road_key="R_"+sha1_text(f"{z}/{tx}/{ty}/{layer_name}/{fid}/{geometry_json}",18)
            directed=None
            if sign:
                directed=(axis_bearing+(180.0 if sign<0 else 0.0))%360.0
                mode="oneway"
                conf="high" if dist<=15 else ("medium" if dist<=30 else "low")
            else:
                mode="both"
                conf="both"
            out.append(RoadMetric(
                road_key=road_key,layer=layer_name,feature_id=fid,tile_z=z,tile_x=tx,tile_y=ty,distance_m=dist,
                axis_bearing_deg=axis_bearing,directed_bearing_deg=directed,oneway=1 if sign else 0,
                direction_mode=mode,direction_confidence=conf,direction_source=dir_source,
                speed_limit=speed,road_name=road_name,road_highway=hwy,
                road_properties_json=json.dumps(props,ensure_ascii=False,separators=(",",":")),
                geometry_json=geometry_json,
            ))
    return out


def maybe_infer_parallel_direction(candidates: List[RoadMetric]) -> Optional[Tuple[RoadMetric,float,str]]:
    """Conservative optional inference for divided carriageways.

    We only return an inference if the nearest high-class road has a distinct, nearby,
    parallel candidate whose raw geometry runs in the opposite direction. This does NOT
    prove legal one-way direction; therefore the inferred runtime confidence is kept
    separate by caller and can be disabled with --no-parallel-inference.
    """
    if len(candidates)<2:
        return None
    c=sorted(candidates,key=lambda r:r.distance_m)
    a=c[0]
    if normalize_text(a.road_highway) not in DIRECTIONAL_CLASSES or a.distance_m>20:
        return None
    for b in c[1:8]:
        if b.distance_m < a.distance_m+6 or b.distance_m>90:
            continue
        if normalize_text(b.road_highway) != normalize_text(a.road_highway):
            continue
        axis=min(angle_diff(a.axis_bearing_deg,b.axis_bearing_deg),angle_diff(a.axis_bearing_deg,(b.axis_bearing_deg+180)%360))
        raw=angle_diff(a.axis_bearing_deg,b.axis_bearing_deg)
        if axis<=15 and raw>=150:
            name_a=normalize_text(a.road_name); name_b=normalize_text(b.road_name)
            if name_a and name_b and name_a!=name_b:
                # Different directional carriageway names are actually useful evidence.
                pass
            return a,a.axis_bearing_deg,"parallel_carriageway_geometry"
    return None


def enrich_all_cameras(con: sqlite3.Connection, provider: ProviderConfig, z: int, cache_root: Path,
                       timeout: int, retries: int, request_gap: float, match_max_m: float,
                       candidate_radius_m: float, edge_trigger_m: float, infer_parallel: bool) -> None:
    rows=con.execute("SELECT camera_uid,latitude,longitude,tile_x,tile_y FROM cameras ORDER BY camera_uid").fetchall()
    updated=0; unresolved=0; explicit=0; inferred=0
    for i,(uid,lat,lon,tx0,ty0) in enumerate(rows,1):
        allc: Dict[str,RoadMetric]={}
        tiles=candidate_tiles_for_camera(lat,lon,z,edge_trigger_m)
        # Always evaluate the camera tile first. If no good road, search all 8 neighbors.
        first=tiles[:1]
        rest=tiles[1:]
        search=first
        while True:
            for tx,ty in search:
                try:
                    for rm in basemap_road_metrics(provider,z,tx,ty,lat,lon,cache_root,timeout,retries,request_gap,candidate_radius_m):
                        if rm.road_key not in allc or rm.distance_m<allc[rm.road_key].distance_m:
                            allc[rm.road_key]=rm
                except Exception as e:
                    con.execute("INSERT OR REPLACE INTO tile_status(kind,z,x,y,status,error,updated_at) VALUES('basemap',?,?,?,'failed',?,CURRENT_TIMESTAMP)",(z,tx,ty,f"{type(e).__name__}: {e}"))
            best=min(allc.values(),key=lambda r:r.distance_m) if allc else None
            if rest and (best is None or best.distance_m>match_max_m):
                search=rest; rest=[]; continue
            break
        candidates=sorted(allc.values(),key=lambda r:r.distance_m)
        con.execute("DELETE FROM camera_road_candidates WHERE camera_uid=?",(uid,))
        for rank,rm in enumerate(candidates[:12],1):
            con.execute("""INSERT OR REPLACE INTO roads(road_key,layer,feature_id,road_name,road_highway,speed_limit,
                axis_bearing,directed_bearing,oneway,direction_mode,direction_confidence,direction_source,tile_z,tile_x,tile_y,
                properties_json,geometry_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (rm.road_key,rm.layer,rm.feature_id,rm.road_name,rm.road_highway,rm.speed_limit,rm.axis_bearing_deg,
                 rm.directed_bearing_deg,rm.oneway,rm.direction_mode,rm.direction_confidence,rm.direction_source,rm.tile_z,
                 rm.tile_x,rm.tile_y,rm.road_properties_json,rm.geometry_json))
            con.execute("INSERT OR REPLACE INTO camera_road_candidates(camera_uid,road_key,distance_m,rank_no) VALUES(?,?,?,?)",
                        (uid,rm.road_key,rm.distance_m,rank))

        if not best or best.distance_m>match_max_m:
            unresolved+=1
            con.execute("""UPDATE cameras SET speed_limit=NULL,road_name='',road_highway='',road_distance_m=NULL,
                speed_source='',speed_confidence='unknown',road_bearing=NULL,road_axis_bearing=NULL,oneway=0,
                direction_mode='unknown',direction_confidence='unknown',direction_source='',road_layer='',matched_road_key=NULL,
                road_properties_json=NULL WHERE camera_uid=?""",(uid,))
        else:
            rb=best.directed_bearing_deg if best.oneway and best.directed_bearing_deg is not None else best.axis_bearing_deg
            mode=best.direction_mode; conf=best.direction_confidence; dsrc=best.direction_source; oneway=best.oneway
            if oneway:
                explicit+=1
            elif infer_parallel:
                inf=maybe_infer_parallel_direction(candidates)
                if inf:
                    _,ib,src=inf
                    rb=ib; oneway=1; mode="inferred_oneway"; conf="medium"; dsrc=src; inferred+=1
            speed_conf="high" if best.distance_m<=15 else ("medium" if best.distance_m<=30 else "low")
            speed_source=parse_speed_limit(json.loads(best.road_properties_json))[1] if best.speed_limit is not None else ""
            con.execute("""UPDATE cameras SET speed_limit=?,road_name=?,road_highway=?,road_distance_m=?,speed_source=?,
                speed_confidence=?,road_bearing=?,road_axis_bearing=?,oneway=?,direction_mode=?,direction_confidence=?,
                direction_source=?,road_layer=?,matched_road_key=?,road_properties_json=? WHERE camera_uid=?""",
                (best.speed_limit,best.road_name,best.road_highway,best.distance_m,speed_source,speed_conf,rb,best.axis_bearing_deg,
                 oneway,mode,conf,dsrc,best.layer,best.road_key,best.road_properties_json,uid))
            updated+=1
        if i%100==0 or i==len(rows):
            con.commit(); print(f"road enrichment {i}/{len(rows)} matched={updated} explicit_oneway={explicit} inferred={inferred} unresolved={unresolved}")
    con.commit()


def store_regions(con: sqlite3.Connection, levels: Sequence[str], cache_root: Path) -> Dict[str,List[Tuple[str,str,Any]]]:
    result: Dict[str,List[Tuple[str,str,Any]]]={}
    for level in levels:
        fc=load_boundary_level(level,cache_root)
        items=[]
        for idx,f in enumerate(fc.get("features",[])):
            props=f.get("properties",{}) or {}
            name=str(props.get("shapeName") or props.get("name") or f"{level}_{idx+1}")
            sid=str(props.get("shapeID") or props.get("shapeISO") or idx+1)
            rid=f"{level}:{sid}"
            g=shape(f["geometry"])
            con.execute("INSERT OR REPLACE INTO regions(region_id,adm_level,region_name,source_shape_id,geometry_json) VALUES(?,?,?,?,?)",
                        (rid,level,name,sid,json.dumps(mapping(g),ensure_ascii=False,separators=(",",":"))))
            items.append((rid,name,g))
        con.commit(); result[level]=items
        print(f"regions {level}: {len(items)}")
    return result


def assign_camera_regions(con: sqlite3.Connection, regions: Dict[str,List[Tuple[str,str,Any]]]) -> None:
    cams=con.execute("SELECT camera_uid,latitude,longitude FROM cameras").fetchall()
    con.execute("DELETE FROM camera_regions")
    for level,items in regions.items():
        prepared=[(rid,name,g,prep(g)) for rid,name,g in items]
        assigned=0; nearest=0
        for uid,lat,lon in cams:
            p=Point(lon,lat)
            hits=[rid for rid,name,g,pg in prepared if pg.covers(p)]
            if hits:
                for rid in hits:
                    con.execute("INSERT OR IGNORE INTO camera_regions(camera_uid,region_id,assignment_method) VALUES(?,?,'covers')",(uid,rid))
                assigned+=1
                continue
            # Boundary datasets can have tiny topology gaps. Assign nearest polygon only if very close (~3 km).
            best=None
            for rid,name,g,pg in prepared:
                d=g.distance(p)
                if best is None or d<best[0]: best=(d,rid)
            if best and best[0] <= 0.03:
                con.execute("INSERT OR IGNORE INTO camera_regions(camera_uid,region_id,assignment_method) VALUES(?,?,'nearest')",(uid,best[1]))
                assigned+=1; nearest+=1
        con.commit(); print(f"assign {level}: {assigned}/{len(cams)} cameras (nearest-fallback={nearest})")


def export_runtime_db(master: sqlite3.Connection, out_db: Path, where_sql: str = "1=1", params: Tuple[Any,...]=()) -> int:
    out_db.parent.mkdir(parents=True,exist_ok=True)
    if out_db.exists(): out_db.unlink()
    dst=sqlite3.connect(out_db)
    dst.execute("""CREATE TABLE cameras(
        camera_id TEXT NOT NULL,
        camera_type TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        speed_limit INTEGER,
        road_name TEXT,
        road_highway TEXT,
        road_distance_m REAL,
        speed_source TEXT,
        speed_confidence TEXT,
        road_bearing REAL,
        oneway INTEGER NOT NULL DEFAULT 0,
        direction_mode TEXT,
        direction_confidence TEXT,
        road_layer TEXT
    )""")
    sql=f"""SELECT camera_uid,camera_type,latitude,longitude,speed_limit,COALESCE(road_name,''),COALESCE(road_highway,''),
        road_distance_m,COALESCE(speed_source,''),COALESCE(speed_confidence,'unknown'),road_bearing,oneway,
        COALESCE(direction_mode,'unknown'),COALESCE(direction_confidence,'unknown'),COALESCE(road_layer,'')
        FROM cameras WHERE {where_sql} ORDER BY latitude,longitude,camera_uid"""
    rows=master.execute(sql,params).fetchall()
    dst.executemany("INSERT INTO cameras VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",rows)
    dst.execute("CREATE INDEX idx_cam_ll ON cameras(latitude,longitude)")
    dst.execute("CREATE INDEX idx_cam_id ON cameras(camera_id)")
    dst.commit(); ok=dst.execute("PRAGMA integrity_check").fetchone()[0]; dst.close()
    if ok!="ok": raise RuntimeError(f"runtime DB integrity failed: {out_db}")
    return len(rows)


def export_raw_csv(master: sqlite3.Connection, out_csv: Path, region_id: Optional[str]=None) -> int:
    out_csv.parent.mkdir(parents=True,exist_ok=True)
    if region_id:
        sql="""SELECT c.* FROM cameras c JOIN camera_regions cr ON cr.camera_uid=c.camera_uid WHERE cr.region_id=? ORDER BY c.latitude,c.longitude"""
        rows=master.execute(sql,(region_id,)).fetchall()
    else:
        rows=master.execute("SELECT * FROM cameras ORDER BY latitude,longitude").fetchall()
    cols=[d[1] for d in master.execute("PRAGMA table_info(cameras)").fetchall()]
    with out_csv.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f); w.writerow(cols); w.writerows(rows)
    return len(rows)


def export_roads_db(master: sqlite3.Connection, out_db: Path, region_id: Optional[str]=None) -> int:
    out_db.parent.mkdir(parents=True,exist_ok=True)
    if out_db.exists(): out_db.unlink()
    dst=sqlite3.connect(out_db)
    dst.executescript("""CREATE TABLE roads AS SELECT '' AS road_key,'' AS layer,'' AS feature_id,'' AS road_name,'' AS road_highway,
        NULL AS speed_limit,NULL AS axis_bearing,NULL AS directed_bearing,0 AS oneway,'' AS direction_mode,'' AS direction_confidence,
        '' AS direction_source,NULL AS tile_z,NULL AS tile_x,NULL AS tile_y,'' AS properties_json,'' AS geometry_json WHERE 0;
        CREATE TABLE camera_road_candidates(camera_id TEXT,road_key TEXT,distance_m REAL,rank_no INTEGER);
    """)
    if region_id:
        road_rows=master.execute("""SELECT DISTINCT r.* FROM roads r JOIN camera_road_candidates crc ON crc.road_key=r.road_key
            JOIN camera_regions cr ON cr.camera_uid=crc.camera_uid WHERE cr.region_id=?""",(region_id,)).fetchall()
        cand=master.execute("""SELECT crc.camera_uid,crc.road_key,crc.distance_m,crc.rank_no FROM camera_road_candidates crc
            JOIN camera_regions cr ON cr.camera_uid=crc.camera_uid WHERE cr.region_id=?""",(region_id,)).fetchall()
    else:
        road_rows=master.execute("SELECT * FROM roads").fetchall(); cand=master.execute("SELECT * FROM camera_road_candidates").fetchall()
    if road_rows:
        dst.executemany("INSERT INTO roads VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",road_rows)
    if cand:
        dst.executemany("INSERT INTO camera_road_candidates VALUES(?,?,?,?)",cand)
    dst.commit(); dst.close(); return len(road_rows)


def write_region_outputs(master: sqlite3.Connection, out_root: Path, levels: Sequence[str]) -> None:
    # Iran master outputs.
    country=out_root/"IRAN_ALL"
    n=export_runtime_db(master,country/"cameras_mojodrive.sqlite")
    export_raw_csv(master,country/"cameras_full.csv")
    export_roads_db(master,country/"roads_near_cameras.sqlite")
    print(f"export IRAN_ALL cameras={n}")

    index_rows=[]
    for level in levels:
        regs=master.execute("SELECT region_id,region_name,source_shape_id FROM regions WHERE adm_level=? ORDER BY region_name",(level,)).fetchall()
        for rid,name,sid in regs:
            cnt=master.execute("SELECT COUNT(*) FROM camera_regions WHERE region_id=?",(rid,)).fetchone()[0]
            index_rows.append((level,rid,name,sid,cnt))
            if cnt==0: continue
            folder=out_root/level/(slugify(name)+"__"+sha1_text(rid,6))
            where="camera_uid IN (SELECT camera_uid FROM camera_regions WHERE region_id=?)"
            export_runtime_db(master,folder/"cameras_mojodrive.sqlite",where,(rid,))
            export_raw_csv(master,folder/"cameras_full.csv",rid)
            export_roads_db(master,folder/"roads_near_cameras.sqlite",rid)
            meta={"region_id":rid,"adm_level":level,"name":name,"source_shape_id":sid,"camera_count":cnt}
            (folder/"region.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
    with (out_root/"regions_index.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f); w.writerow(["adm_level","region_id","region_name","source_shape_id","camera_count"]); w.writerows(index_rows)


def export_custom_cities(master: sqlite3.Connection, custom_geojson: Path, out_root: Path) -> None:
    fc=json.loads(custom_geojson.read_text(encoding="utf-8"))
    city_root=out_root/"CITIES_CUSTOM"
    cams=master.execute("SELECT camera_uid,latitude,longitude FROM cameras").fetchall()
    for idx,f in enumerate(fc.get("features",[])):
        props=f.get("properties",{}) or {}; name=str(props.get("name") or props.get("NAME") or props.get("shapeName") or f"city_{idx+1}")
        g=shape(f["geometry"]); pg=prep(g); ids=[uid for uid,lat,lon in cams if pg.covers(Point(lon,lat))]
        if not ids: continue
        folder=city_root/(slugify(name)+"__"+sha1_text(name+str(idx),6)); folder.mkdir(parents=True,exist_ok=True)
        q=",".join("?" for _ in ids)
        export_runtime_db(master,folder/"cameras_mojodrive.sqlite",f"camera_uid IN ({q})",tuple(ids))
        # raw CSV direct for custom city
        rows=master.execute(f"SELECT * FROM cameras WHERE camera_uid IN ({q}) ORDER BY latitude,longitude",tuple(ids)).fetchall()
        cols=[d[1] for d in master.execute("PRAGMA table_info(cameras)")]
        with (folder/"cameras_full.csv").open("w",newline="",encoding="utf-8-sig") as fh:
            w=csv.writer(fh); w.writerow(cols); w.writerows(rows)
        (folder/"region.json").write_text(json.dumps({"name":name,"camera_count":len(ids)},ensure_ascii=False,indent=2),encoding="utf-8")


def quality_reports(con: sqlite3.Connection, out_root: Path) -> Dict[str,Any]:
    rep=out_root/"reports"; rep.mkdir(parents=True,exist_ok=True)
    total=con.execute("SELECT COUNT(*) FROM cameras").fetchone()[0]
    matched=con.execute("SELECT COUNT(*) FROM cameras WHERE matched_road_key IS NOT NULL").fetchone()[0]
    directed=con.execute("SELECT COUNT(*) FROM cameras WHERE oneway=1 AND road_bearing IS NOT NULL AND direction_confidence IN ('high','medium')").fetchone()[0]
    explicit=con.execute("SELECT COUNT(*) FROM cameras WHERE direction_source LIKE 'property:%'").fetchone()[0]
    inferred=con.execute("SELECT COUNT(*) FROM cameras WHERE direction_source='parallel_carriageway_geometry'").fetchone()[0]
    unresolved=con.execute("SELECT COUNT(*) FROM cameras WHERE matched_road_key IS NULL OR direction_confidence='unknown'").fetchone()[0]
    summary={"total_cameras":total,"road_matched":matched,"reliable_directed":directed,"explicit_oneway":explicit,
             "parallel_inferred":inferred,"unresolved":unresolved}
    (rep/"quality_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    rows=con.execute("""SELECT camera_uid,source_camera_id,camera_type,latitude,longitude,road_name,road_highway,road_distance_m,
        road_bearing,oneway,direction_mode,direction_confidence,direction_source FROM cameras
        WHERE matched_road_key IS NULL OR direction_confidence IN ('unknown','low','both')
        ORDER BY road_highway,latitude,longitude""").fetchall()
    with (rep/"needs_direction_review.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f); w.writerow(["camera_id","source_camera_id","type","lat","lon","road_name","road_highway","road_distance_m",
                                     "road_bearing","oneway","direction_mode","direction_confidence","direction_source"]); w.writerows(rows)
    return summary


def verify_completeness(con: sqlite3.Connection, country_tiles: int, levels: Sequence[str], out_root: Path) -> bool:
    failed=con.execute("SELECT COUNT(*) FROM tile_status WHERE kind='traffic' AND status!='ok'").fetchone()[0]
    ok=con.execute("SELECT COUNT(*) FROM tile_status WHERE kind='traffic' AND status='ok'").fetchone()[0]
    total_cams=con.execute("SELECT COUNT(*) FROM cameras").fetchone()[0]
    hierarchy={}
    for level in levels:
        assigned=con.execute("""SELECT COUNT(DISTINCT camera_uid) FROM camera_regions cr JOIN regions r ON r.region_id=cr.region_id WHERE r.adm_level=?""",(level,)).fetchone()[0]
        hierarchy[level]={"assigned_unique":assigned,"master_total":total_cams,"coverage_pct":round(100*assigned/max(1,total_cams),3)}
    report={"traffic_tiles_expected":country_tiles,"traffic_tiles_ok":ok,"traffic_tiles_failed":failed,"master_cameras":total_cams,
            "hierarchy":hierarchy,"complete":failed==0 and ok>=country_tiles}
    (out_root/"reports").mkdir(parents=True,exist_ok=True)
    (out_root/"reports"/"completeness.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    return bool(report["complete"])


def self_test() -> None:
    assert round(bearing_from_xy(1,0),6)==90.0
    assert round(bearing_from_xy(0,1),6)==0.0
    assert angle_diff(359,1)==2
    assert parse_oneway({"oneway":1})[0]==1
    assert parse_oneway({"oneway":"-1"})[0]==-1
    assert parse_oneway({"oneway":0})[0]==0
    assert parse_speed_limit({"routable":110})[0]==110
    assert camera_kind("report_map_camera_speed")=="speed"
    assert is_camera_poi("report_map_camera_speed")
    a=RoadMetric("a","street","",14,1,1,5,10,None,0,"both","both","not_exposed",110,"A","trunk","{}","{}")
    b=RoadMetric("b","street","",14,1,1,35,190,None,0,"both","both","not_exposed",110,"B","trunk","{}","{}")
    inf=maybe_infer_parallel_direction([a,b]); assert inf is not None
    print("SELF-TEST: PASS")


def main() -> int:
    ap=argparse.ArgumentParser(description="Build one consistent Iran MOJODrive camera+road snapshot, then split it by admin region.")
    ap.add_argument("--legacy-config",type=Path,help="Existing working extractor .py; reads literal KEY/URL/BASEMAP_URL/HEADERS without executing it")
    ap.add_argument("--provider-config",type=Path,help="Local JSON with xor_key_hex, traffic_url, basemap_url, headers")
    ap.add_argument("--out",type=Path,default=Path("iran_mojodrive_dataset"))
    ap.add_argument("--zoom",type=int,default=DEFAULT_Z)
    ap.add_argument("--workers",type=int,default=DEFAULT_WORKERS)
    ap.add_argument("--timeout",type=int,default=DEFAULT_TIMEOUT)
    ap.add_argument("--retries",type=int,default=DEFAULT_RETRIES)
    ap.add_argument("--request-gap",type=float,default=DEFAULT_REQUEST_GAP)
    ap.add_argument("--levels",nargs="+",default=list(DEFAULT_LEVELS),choices=["ADM1","ADM2","ADM3","ADM4"])
    ap.add_argument("--custom-cities",type=Path,help="Optional exact city-boundary GeoJSON; exported under CITIES_CUSTOM")
    ap.add_argument("--road-match-max-m",type=float,default=DEFAULT_ROAD_MATCH_MAX_M)
    ap.add_argument("--road-candidate-radius-m",type=float,default=DEFAULT_ROAD_CANDIDATE_RADIUS_M)
    ap.add_argument("--edge-neighbor-trigger-m",type=float,default=DEFAULT_EDGE_NEIGHBOR_TRIGGER_M)
    ap.add_argument("--no-parallel-inference",action="store_true",help="Disable conservative divided-carriageway direction inference")
    ap.add_argument("--allow-incomplete",action="store_true",help="Do not exit non-zero if traffic tiles still failed")
    ap.add_argument("--self-test",action="store_true")
    args=ap.parse_args()
    if args.self_test:
        self_test(); return 0

    provider=load_provider_config(args.legacy_config,args.provider_config)
    out=args.out.resolve(); cache=out/"cache"; out.mkdir(parents=True,exist_ok=True)
    master_path=out/"master"/"iran_master.sqlite"; con=init_master_db(master_path)
    put_meta(con,"zoom",args.zoom); put_meta(con,"created_unix",int(time.time())); put_meta(con,"design","single_snapshot_then_split")

    print("Loading Iran ADM0 boundary...")
    adm0=load_boundary_level("ADM0",cache)
    country_geom=unary_union([shape(f["geometry"]) for f in adm0.get("features",[])])
    tiles=build_tile_list(country_geom,args.zoom)
    print(f"Iran tiles at z={args.zoom}: {len(tiles)}")

    download_traffic_snapshot(con,provider,tiles,args.zoom,cache,args.workers,args.timeout,args.retries,args.request_gap)
    extract_cameras_from_cached_traffic(con,provider,tiles,country_geom,args.zoom,cache)
    enrich_all_cameras(con,provider,args.zoom,cache,args.timeout,args.retries,args.request_gap,args.road_match_max_m,
                       args.road_candidate_radius_m,args.edge_neighbor_trigger_m,not args.no_parallel_inference)

    regions=store_regions(con,args.levels,cache)
    assign_camera_regions(con,regions)
    write_region_outputs(con,out/"exports",args.levels)
    if args.custom_cities:
        export_custom_cities(con,args.custom_cities,out/"exports")
    summary=quality_reports(con,out)
    complete=verify_completeness(con,len(tiles),args.levels,out)
    con.commit(); con.close()

    print("\nDONE")
    print("Master:",master_path)
    print("Exports:",out/"exports")
    print("Quality:",json.dumps(summary,ensure_ascii=False))
    print("Snapshot completeness:","PASS" if complete else "INCOMPLETE - rerun to retry failed tiles")
    if not complete and not args.allow_incomplete:
        return 4
    return 0


if __name__=="__main__":
    raise SystemExit(main())
